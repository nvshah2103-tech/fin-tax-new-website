# Fintax Services – self-hosting notes

Test the build on your computer first (Node 22 required):

    npm install
    # macOS/Linux:
    NITRO_PRESET=static npm run build
    # Windows PowerShell:
    $env:NITRO_PRESET="static"; npm run build

Then check that `.output/public/index.html` exists.

Cloudflare Pages settings:
- Build command: `npm run build`
- Build output directory: `.output/public`
- Environment variables: `NITRO_PRESET` = `static`, `NODE_VERSION` = `22`

Before launch: put a 1200x630 image at `public/og-image.png` (social preview).
