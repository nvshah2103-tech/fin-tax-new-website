import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { FloatingButtons } from "@/components/site/FloatingButtons";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-7xl font-extrabold text-[var(--navy)]">404</h1>
        <h2 className="mt-4 text-xl font-semibold">Page not found</h2>
        <p className="mt-2 text-sm text-[var(--muted-ink)]">The page you're looking for doesn't exist or has been moved.</p>
        <Link to="/" className="mt-6 inline-flex items-center justify-center rounded-md bg-[var(--green)] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[var(--green-dark)]">
          Go home
        </Link>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold">This page didn't load</h1>
        <p className="mt-2 text-sm text-[var(--muted-ink)]">Something went wrong. Please try again.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button onClick={() => { router.invalidate(); reset(); }}
            className="inline-flex items-center justify-center rounded-md bg-[var(--green)] px-4 py-2 text-sm font-semibold text-white">
            Try again
          </button>
          <a href="/" className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium">Go home</a>
        </div>
      </div>
    </div>
  );
}

const orgJsonLd = {
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  name: "Fintax Services",
  description:
    "Tax Practitioners and Financial Consultants offering GST, Income Tax, Accounting, Audit Support, and Business Registration services in Gujarat, India.",
  url: "https://www.fintaxservices.in",
  email: "fintax3107@gmail.com",
  telephone: "+919033096187",
  address: {
    "@type": "PostalAddress",
    streetAddress: "05, Beside St. Xavier's High School, Nr. Highway",
    addressLocality: "Kalol",
    addressRegion: "Gujarat",
    postalCode: "382721",
    addressCountry: "IN",
  },
  openingHoursSpecification: {
    "@type": "OpeningHoursSpecification",
    dayOfWeek: ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
    opens: "10:00",
    closes: "20:00",
  },

  hasOfferCatalog: {
    "@type": "OfferCatalog",
    name: "Financial & Tax Services",
    itemListElement: [
      { "@type": "Offer", itemOffered: { "@type": "Service", name: "GST Compliance" } },
      { "@type": "Offer", itemOffered: { "@type": "Service", name: "Income Tax Filing" } },
      { "@type": "Offer", itemOffered: { "@type": "Service", name: "Accounting & Bookkeeping" } },
      { "@type": "Offer", itemOffered: { "@type": "Service", name: "Audit Support" } },
      { "@type": "Offer", itemOffered: { "@type": "Service", name: "Business Registration" } },
      { "@type": "Offer", itemOffered: { "@type": "Service", name: "Tax Consultancy" } },
    ],
  },
  priceRange: "₹₹",
  sameAs: ["https://wa.me/919033096187"],
};

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { name: "robots", content: "index, follow" },
      { title: "Fintax Services — Tax Practitioners & Financial Consultants in Gujarat" },
      { name: "description", content: "Professional GST, Income Tax, Accounting, Audit Support and Business Registration services in Kalol, Gujarat. Trusted Tax Practitioners for individuals, MSMEs and businesses." },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "Fintax Services" },
      { property: "og:locale", content: "en_IN" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:title", content: "Fintax Services — Tax Practitioners & Financial Consultants in Gujarat" },
      { name: "twitter:title", content: "Fintax Services — Tax Practitioners & Financial Consultants in Gujarat" },
      { property: "og:description", content: "Professional GST, Income Tax, Accounting, Audit Support and Business Registration services in Kalol, Gujarat. Trusted Tax Practitioners for individuals, MSMEs and businesses." },
      { name: "twitter:description", content: "Professional GST, Income Tax, Accounting, Audit Support and Business Registration services in Kalol, Gujarat. Trusted Tax Practitioners for individuals, MSMEs and businesses." },
      { property: "og:image", content: "https://www.fintaxservices.in/og-image.png" },
      { name: "twitter:image", content: "https://www.fintaxservices.in/og-image.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Montserrat:wght@400;700;800&display=swap" },
    ],
    scripts: [
      { type: "application/ld+json", children: JSON.stringify(orgJsonLd) },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

/**
 * Sitemap routes:
 *  /            Home
 *  /services    Services
 *  /about       About Us
 *  /corporate   For Businesses
 *  /contact     Contact
 */
function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <div className="flex min-h-screen flex-col">
        <Navbar />
        <main className="flex-1" style={{ paddingTop: "72px" }}>
          <Outlet />
        </main>
        <Footer />
        <FloatingButtons />
      </div>
      <style>{`@media (min-width: 768px){ main{ padding-top: 76px !important; } }`}</style>
    </QueryClientProvider>
  );
}
