import { createFileRoute, Link } from "@tanstack/react-router";
import { FileText, Calculator, BookOpen, ShieldCheck, Building2, Lightbulb, CheckCircle, Clock, Shield } from "lucide-react";
import { FadeUp, SectionLabel } from "@/components/site/Section";
import { CorporateForm } from "@/components/site/Forms";
import { SITE_URL } from "@/lib/site";

export const Route = createFileRoute("/corporate")({
  head: () => ({
    meta: [
      { title: "Business & Corporate Solutions — Fintax Services" },
      { name: "description", content: "Corporate tax, GST compliance, accounting, payroll, audit support, and company formation services for businesses in Gujarat. Submit your business enquiry." },
      { property: "og:title", content: "Business & Corporate Solutions — Fintax Services" },
      { property: "og:description", content: "Tailored tax, accounting, and compliance solutions for MSMEs and corporates." },
      { property: "og:url", content: `${SITE_URL}/corporate` },
      { name: "twitter:title", content: "Business & Corporate Solutions" },
      { name: "twitter:description", content: "Tailored tax and compliance for MSMEs and corporates." },
    ],
    links: [{ rel: "canonical", href: `${SITE_URL}/corporate` }],
  }),
  component: Corporate,
});

const bizServices = [
  { icon: FileText, title: "GST Registration & Monthly Compliance" },
  { icon: Calculator, title: "Income Tax & TDS Returns" },
  { icon: BookOpen, title: "Full-Scale Accounting & Payroll" },
  { icon: ShieldCheck, title: "Internal & Concurrent Audit Support" },
  { icon: Building2, title: "Company Formation & ROC Compliance" },
  { icon: Lightbulb, title: "Strategic Tax Planning & Advisory" },
];

function Corporate() {
  return (
    <>
      <section className="bg-[var(--alt)] py-14" aria-label="Corporate hero">
        <div className="mx-auto max-w-7xl px-6 md:px-10">
          <nav aria-label="Breadcrumb" className="text-xs text-[var(--muted-ink)]">
            <ol className="flex gap-2">
              <li><Link to="/" className="hover:text-[var(--green)]">Home</Link></li><li>›</li>
              <li className="font-semibold text-[var(--navy)]">For Businesses</li>
            </ol>
          </nav>
          <h1 className="mt-4 font-display text-4xl font-extrabold md:text-5xl">Business & Corporate Solutions</h1>
        </div>
      </section>

      <section className="py-20" aria-label="Corporate intro">
        <div className="mx-auto w-full max-w-[760px] px-6 md:px-10">
          <FadeUp>
            <SectionLabel>For your business</SectionLabel>
            <h2 className="mt-3 font-display text-3xl font-extrabold md:text-4xl">Solutions that Scale With You</h2>
            <p className="mt-6 text-base leading-relaxed text-[var(--foreground)]">
              Whether you are a startup just getting off the ground, an established MSME, or a larger business house looking for reliable ongoing support — Fintax Services delivers tailored tax and financial solutions that scale with your business. From GST registration on Day 1 to company-wide annual compliance, our team handles everything with precision, accountability, and complete discretion.
            </p>
          </FadeUp>
          <div className="mt-10 flex flex-col gap-5">
            {[
              { icon: CheckCircle, title: "End-to-End Compliance", desc: "From GST registration to annual ROC filing — everything handled under one roof." },
              { icon: Clock, title: "Deadline-Driven Delivery", desc: "We ensure zero missed filings, returns, or compliance dates for your business." },
              { icon: Shield, title: "Complete Confidentiality", desc: "Your business financial data is handled with total discretion and professional ethics." },
            ].map((s, i) => (
              <FadeUp key={s.title} delay={i * 0.08}>
                <div
                  className="flex flex-col items-center gap-4 rounded-[10px] bg-white text-center card-shadow sm:flex-row sm:text-left"
                  style={{ padding: "20px 24px" }}
                >
                  <span
                    className="flex shrink-0 items-center justify-center rounded-full"
                    style={{ width: "56px", height: "56px", background: "#E8F5E9" }}
                  >
                    <s.icon size={28} style={{ color: "var(--green)" }} />
                  </span>
                  <div>
                    <h3 className="font-display text-lg font-bold">{s.title}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-[var(--muted-ink)]">{s.desc}</p>
                  </div>
                </div>
              </FadeUp>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-[var(--alt)] py-20" aria-label="Business services">
        <div className="mx-auto max-w-7xl px-6 md:px-10">
          <FadeUp className="text-center">
            <SectionLabel>What we deliver</SectionLabel>
            <h2 className="mt-3 font-display text-3xl font-extrabold md:text-4xl">Services for Businesses</h2>
          </FadeUp>
          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {bizServices.map((s, i) => (
              <FadeUp key={s.title} delay={i * 0.04}>
                <div className="flex h-full items-start gap-4 rounded-[10px] bg-white p-6 card-shadow">
                  <s.icon className="shrink-0 text-[var(--navy)]" size={28} />
                  <h3 className="font-display text-base font-bold">{s.title}</h3>
                </div>
              </FadeUp>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20" aria-label="Business enquiry">
        <div className="mx-auto max-w-4xl px-6 md:px-10">
          <FadeUp className="text-center">
            <SectionLabel>Enquire</SectionLabel>
            <h2 className="mt-3 font-display text-3xl font-extrabold md:text-4xl">Submit Your Business Enquiry</h2>
            <p className="mx-auto mt-3 max-w-2xl text-sm text-[var(--muted-ink)]">
              Fill in the details below. When you press submit, a structured message will open in WhatsApp — just press Send. Our team will respond within 24 hours.
            </p>
          </FadeUp>
          <FadeUp delay={0.1}>
            <div className="mt-10"><CorporateForm /></div>
          </FadeUp>
        </div>
      </section>
    </>
  );
}
