import { createFileRoute, Link } from "@tanstack/react-router";
import { MapPin, Mail, Phone, MessageCircle, Clock } from "lucide-react";
import { FadeUp } from "@/components/site/Section";
import { ContactForm } from "@/components/site/Forms";
import { ADDRESS, EMAIL, HOURS, MAPS_EMBED, PHONE, PHONE_DISPLAY, SITE_URL, waUrl } from "@/lib/site";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Fintax Services — Tax Consultants in Kalol, Gujarat" },
      { name: "description", content: "Get in touch with Fintax Services for GST, Income Tax, Accounting, and Business Registration support. Call, WhatsApp, or visit our office in Kalol, Gujarat." },
      { property: "og:title", content: "Contact Fintax Services" },
      { property: "og:description", content: "Reach our tax practitioners in Kalol, Gujarat by phone, WhatsApp, or email." },
      { property: "og:url", content: `${SITE_URL}/contact` },
      { name: "twitter:title", content: "Contact Fintax Services" },
      { name: "twitter:description", content: "Reach our tax practitioners in Kalol, Gujarat." },
    ],
    links: [{ rel: "canonical", href: `${SITE_URL}/contact` }],
  }),
  component: Contact,
});

function Contact() {
  return (
    <>
      <section className="bg-[var(--alt)] py-14" aria-label="Contact hero">
        <div className="mx-auto max-w-7xl px-6 md:px-10">
          <nav aria-label="Breadcrumb" className="text-xs text-[var(--muted-ink)]">
            <ol className="flex gap-2">
              <li><Link to="/" className="hover:text-[var(--green)]">Home</Link></li><li>›</li>
              <li className="font-semibold text-[var(--navy)]">Contact</li>
            </ol>
          </nav>
          <h1 className="mt-4 font-display text-4xl font-extrabold md:text-5xl">Get in Touch</h1>
        </div>
      </section>

      <section className="py-20" aria-label="Contact details and form">
        <div className="mx-auto grid max-w-7xl gap-10 px-6 md:grid-cols-2 md:px-10">
          <FadeUp>
            <h2 className="font-display text-2xl font-extrabold md:text-3xl">We're Here to Help</h2>
            <p className="mt-3 text-sm text-[var(--muted-ink)]">
              Whether you have a simple tax question or need comprehensive financial support — reach out. We respond promptly.
            </p>
            <ul className="mt-8 space-y-5 text-sm">
              <li className="flex gap-3"><MapPin className="shrink-0 text-[var(--green)]" size={20} /><span>{ADDRESS}</span></li>
              <li className="flex gap-3"><Mail className="shrink-0 text-[var(--green)]" size={20} /><a className="hover:text-[var(--green)]" href={`mailto:${EMAIL}`}>{EMAIL}</a></li>
              <li className="flex gap-3"><Phone className="shrink-0 text-[var(--green)]" size={20} /><a className="hover:text-[var(--green)]" href={`tel:${PHONE}`}>{PHONE_DISPLAY}</a></li>
              <li className="flex gap-3"><MessageCircle className="shrink-0 text-[var(--green)]" size={20} /><a className="hover:text-[var(--green)]" href={waUrl("Hello Fintax Services, I have an enquiry.")} target="_blank" rel="noopener noreferrer">Chat with us on WhatsApp</a></li>
              <li className="flex gap-3"><Clock className="shrink-0 text-[var(--green)]" size={20} /><span>{HOURS}</span></li>
            </ul>
            <div className="mt-8 overflow-hidden rounded-[10px] card-shadow">
              <iframe title="Fintax Services office map" src={MAPS_EMBED} className="h-72 w-full border-0" loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
            </div>
          </FadeUp>

          <FadeUp delay={0.1}>
            <ContactForm />
          </FadeUp>
        </div>
      </section>
    </>
  );
}
