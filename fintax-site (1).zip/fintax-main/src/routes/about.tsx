import { createFileRoute, Link } from "@tanstack/react-router";
import { ShieldCheck, Award, Lock, Heart, Check } from "lucide-react";
import { FadeUp, SectionLabel } from "@/components/site/Section";
import { TeamCards } from "@/components/site/TeamCards";
import { Reviews } from "@/components/site/Reviews";
import { VisionSection } from "@/components/site/VisionSection";
import { LogoMeaning } from "@/components/site/LogoMeaning";
import { SITE_URL } from "@/lib/site";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Fintax Services — Tax Practitioners in Gujarat" },
      { name: "description", content: "Meet the partners behind Fintax Services — Gujarat-based Tax Practitioners and Financial Consultants delivering trusted GST, Income Tax, and business advisory. Right Place, Right Advice." },
      { property: "og:title", content: "About Fintax Services — Right Place, Right Advice" },
      { property: "og:description", content: "Gujarat-based Tax Practitioners and Financial Consultants you can trust." },
      { property: "og:url", content: `${SITE_URL}/about` },
      { name: "twitter:title", content: "About Fintax Services" },
      { name: "twitter:description", content: "Gujarat-based Tax Practitioners and Financial Consultants." },
    ],
    links: [{ rel: "canonical", href: `${SITE_URL}/about` }],
  }),
  component: About,
});

const values = [
  { icon: ShieldCheck, title: "Integrity", desc: "We operate with complete transparency. What we tell you is what we do. No surprises." },
  { icon: Award, title: "Professionalism", desc: "Registered Tax Practitioners upholding the highest standards of the profession." },
  { icon: Lock, title: "Confidentiality", desc: "All client data is handled with the strictest privacy and never shared with any third party." },
  { icon: Heart, title: "Client-First", desc: "Your goals are our goals. We measure our success by your satisfaction and financial wellbeing." },
];

const differentiators = [
  "Registered Tax Practitioners",
  "Expert GST Practitioners",
  "Multi-discipline firm covering tax, accounting, and business registration",
  "Deep knowledge of India's business ecosystem and MSME landscape",
  "Personal relationship with every client — not just transactional service",
  "Transparent fee structure with no hidden charges",
];

function About() {
  return (
    <>
      <section className="bg-[var(--alt)] py-14" aria-label="About hero">
        <div className="mx-auto max-w-7xl px-6 md:px-10">
          <nav aria-label="Breadcrumb" className="text-xs text-[var(--muted-ink)]">
            <ol className="flex gap-2">
              <li><Link to="/" className="hover:text-[var(--green)]">Home</Link></li><li>›</li>
              <li className="font-semibold text-[var(--navy)]">About Us</li>
            </ol>
          </nav>
          <h1 className="mt-4 font-display text-4xl font-extrabold md:text-5xl">About Fintax Services</h1>
        </div>
      </section>

      <section className="py-20" aria-label="Our story">
        <div className="mx-auto max-w-[800px] px-6 md:px-10">
          <FadeUp>
            <SectionLabel>Our Story</SectionLabel>
            <h2 className="mt-3 font-display text-3xl font-extrabold md:text-4xl">A Firm Built on Trust and Transparency</h2>
            <div
              className="mt-8"
              style={{
                borderLeft: "5px solid #2D7A3A",
                background: "#F7F9FC",
                padding: "28px 32px",
                borderRadius: "0 12px 12px 0",
              }}
            >
              <p className="font-display text-[22px] font-bold leading-snug text-[var(--navy)]">
                "Every individual and every business deserves professional, honest financial guidance — without exception."
              </p>
              <p className="mt-4 text-sm font-medium text-[var(--green)]">
                — Fintax Services, Gujarat
              </p>
            </div>
            <p className="mt-8 text-base leading-relaxed text-[var(--foreground)]">
              Fintax Services was founded with one clear belief: every individual and every business deserves access to professional, honest, and transparent financial guidance. We are a Gujarat-based firm of qualified Tax Practitioners and Financial Consultants who are passionate about simplifying the complexity of GST, Income Tax, Accounting, and Business Compliance. We work closely with each client — understanding their unique situation, goals, and challenges — and deliver solutions that are practical, timely, and fully compliant with Indian law. Our commitment is not just to file your returns or register your company — it is to become your long-term financial partner who you can call on anytime, for anything. Based in Gujarat and serving clients across India, Fintax Services is your single, trusted destination for all things finance and taxation.
            </p>
          </FadeUp>
        </div>
      </section>

      {/* VISION */}
      <VisionSection />

      <section className="bg-[var(--alt)] py-20" aria-label="Our values">
        <div className="mx-auto max-w-7xl px-6 md:px-10">
          <FadeUp className="text-center">
            <SectionLabel>Our Values</SectionLabel>
            <h2 className="mt-3 font-display text-3xl font-extrabold md:text-4xl">What We Stand For</h2>
          </FadeUp>
          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {values.map((v, i) => (
              <FadeUp key={v.title} delay={i * 0.05}>
                <div className="h-full rounded-[10px] bg-white p-6 card-shadow">
                  <v.icon className="text-[var(--green)]" size={28} />
                  <h3 className="mt-4 font-display text-lg font-bold">{v.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-[var(--muted-ink)]">{v.desc}</p>
                </div>
              </FadeUp>
            ))}
          </div>
        </div>
      </section>

      {/* LOGO MEANING */}
      <LogoMeaning />

      <section className="py-20" aria-label="Meet the team">
        <div className="mx-auto max-w-7xl px-6 md:px-10">
          <FadeUp className="text-center">
            <h2 className="font-display text-3xl font-extrabold md:text-4xl">Meet Our Team</h2>
          </FadeUp>
          <div className="mt-12"><TeamCards expanded /></div>
        </div>
      </section>

      <section className="bg-[var(--alt)] py-20" aria-label="What differentiates us">
        <div className="mx-auto max-w-5xl px-6 md:px-10">
          <FadeUp className="text-center">
            <SectionLabel>What Differentiates Us</SectionLabel>
            <h2 className="mt-3 font-display text-3xl font-extrabold md:text-4xl">Why Clients Stay With Us</h2>
          </FadeUp>
          <ul className="mt-10 grid gap-4 md:grid-cols-2">
            {differentiators.map((d) => (
              <li key={d} className="flex items-start gap-3 rounded-[10px] bg-white p-4 card-shadow">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[var(--green)]/10 text-[var(--green)]">
                  <Check size={14} strokeWidth={3} />
                </span>
                <span className="text-sm font-medium">{d}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <Reviews />
    </>
  );
}
