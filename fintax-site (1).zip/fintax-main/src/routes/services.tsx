import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { MessageCircle } from "lucide-react";
import { FadeUp } from "@/components/site/Section";
import { ServiceTabs, TAB_DEFS } from "@/components/site/ServiceTabs";
import { AccordionServices } from "@/components/site/AccordionServices";
import { SITE_URL, waUrl } from "@/lib/site";

type SearchParams = { tab?: string };

export const Route = createFileRoute("/services")({
  validateSearch: (search: Record<string, unknown>): SearchParams => ({
    tab: typeof search.tab === "string" ? search.tab : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Tax & Financial Services in Gujarat — Fintax Services" },
      { name: "description", content: "GST, Income Tax, Accounting, Audit Support, Business Registration and Tax Consultancy — explore Fintax Services' complete service catalogue for Gujarat." },
      { property: "og:title", content: "Tax & Financial Services in Gujarat — Fintax Services" },
      { property: "og:description", content: "Complete tax, accounting and business registration services for individuals and businesses across Gujarat." },
      { property: "og:url", content: `${SITE_URL}/services` },
      { name: "twitter:title", content: "Tax & Financial Services — Fintax Services" },
      { name: "twitter:description", content: "Complete services for individuals and businesses across Gujarat." },
    ],
    links: [{ rel: "canonical", href: `${SITE_URL}/services` }],
  }),
  component: Services,
});

function Breadcrumb({ items }: { items: { to?: string; label: string }[] }) {
  return (
    <nav aria-label="Breadcrumb" className="text-xs text-[var(--muted-ink)]">
      <ol className="flex flex-wrap items-center gap-2">
        {items.map((it, i) => (
          <li key={i} className="flex items-center gap-2">
            {it.to ? <Link to={it.to} className="hover:text-[var(--green)]">{it.label}</Link> : <span className="font-semibold text-[var(--navy)]">{it.label}</span>}
            {i < items.length - 1 && <span>›</span>}
          </li>
        ))}
      </ol>
    </nav>
  );
}

function Services() {
  const { tab } = Route.useSearch();
  const validIds = TAB_DEFS.map((t) => t.id);
  const deepLinked = tab && validIds.includes(tab) ? tab : undefined;
  const [activeTab, setActiveTab] = useState<string>(deepLinked ?? TAB_DEFS[0].id);
  const [accordionOpen, setAccordionOpen] = useState<string>(deepLinked ?? "");

  useEffect(() => {
    if (tab && validIds.includes(tab)) {
      setActiveTab(tab);
      setAccordionOpen(tab);
      setTimeout(() => {
        document.getElementById("services-detail")?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  return (
    <>
      <section className="bg-[var(--alt)] py-14" aria-label="Services hero">
        <div className="mx-auto max-w-7xl px-6 md:px-10">
          <Breadcrumb items={[{ to: "/", label: "Home" }, { label: "Services" }]} />
          <h1 className="mt-4 font-display text-4xl font-extrabold md:text-5xl">Our Services</h1>
          <p className="mt-6 max-w-4xl text-base leading-relaxed text-[var(--foreground)]">
            At Fintax Services, we believe every individual and business deserves professional, accurate, and affordable financial and tax support. Our team of qualified Tax Practitioners offers a comprehensive suite of services covering GST compliance, Income Tax filing, Accounting and Bookkeeping, Audit Support, Business Registration, and Tax Consultancy. Whether you are a first-time taxpayer filing your ITR, an MSME managing GST returns, or a growing business looking to register a Private Limited Company — we have the expertise, tools, and dedication to support you at every step. Based in Gujarat and serving clients across India, Fintax Services is your single, trusted destination for all things finance and taxation.
          </p>
        </div>
      </section>

      <section id="services-detail" className="py-16" aria-label="Detailed services">
        <div className="mx-auto w-full max-w-7xl px-6 md:px-10">
          <FadeUp>
            <ServiceTabs detailed active={activeTab} onActiveChange={setActiveTab} />
            <div className="md:hidden">
              <AccordionServices detailed openId={accordionOpen} onOpenChange={setAccordionOpen} />
            </div>
          </FadeUp>
        </div>
      </section>

      <section className="bg-[var(--alt)] py-16" aria-label="Closing CTA">
        <div className="mx-auto max-w-5xl px-6 md:px-10">
          <FadeUp>
            <div className="rounded-[10px] bg-white p-8 text-center card-shadow md:p-12">
              <h2 className="font-display text-2xl font-extrabold md:text-3xl">Not Sure Which Service You Need? Let's Figure It Out Together.</h2>
              <p className="mx-auto mt-3 max-w-2xl text-sm text-[var(--muted-ink)]">Send a quick message — we'll guide you to the right solution for your situation.</p>
              <a href={waUrl("Hello Fintax Services, I'm not sure which service I need. Can you help me?")} target="_blank" rel="noopener noreferrer"
                 className="mt-6 inline-flex items-center gap-2 rounded-lg bg-[var(--green)] px-5 py-3 text-sm font-semibold text-white hover:bg-[var(--green-dark)]">
                <MessageCircle size={18} /> Start a WhatsApp Chat
              </a>
            </div>
          </FadeUp>
        </div>
      </section>
    </>
  );
}
