import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  FileText, Calculator, BookOpen, ShieldCheck, Building2, Lightbulb,
  Lock, Users, Clock, Layers, MessageCircle, Handshake,
  User, Briefcase, Phone, Mail, MapPin, ArrowRight, TrendingUp, Award, LayoutGrid,
} from "lucide-react";
import { FadeUp, SectionLabel } from "@/components/site/Section";
import { ServiceTabs } from "@/components/site/ServiceTabs";
import { AccordionServices } from "@/components/site/AccordionServices";
import { TeamCards } from "@/components/site/TeamCards";
import { Reviews } from "@/components/site/Reviews";
import { VisionSection } from "@/components/site/VisionSection";

import { ADDRESS, EMAIL, HOURS, MAPS_EMBED, PHONE, PHONE_DISPLAY, SITE_URL, waUrl } from "@/lib/site";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Fintax Services — Tax Practitioners & Financial Consultants in Gujarat" },
      { name: "description", content: "Right Place, Right Advice. GST, Income Tax, Accounting, Audit Support and Business Registration services in Kalol, Gujarat. Trusted Tax Practitioners for individuals, MSMEs, and businesses." },
      { property: "og:title", content: "Fintax Services — Right Place, Right Advice" },
      { property: "og:description", content: "Comprehensive GST, Income Tax, Accounting and Business Registration services across Gujarat." },
      { property: "og:url", content: `${SITE_URL}/` },
      { name: "twitter:title", content: "Fintax Services — Right Place, Right Advice" },
      { name: "twitter:description", content: "GST, Income Tax, Accounting and Business Registration across Gujarat." },
    ],
    links: [{ rel: "canonical", href: `${SITE_URL}/` }],
  }),
  component: Home,
});

const services = [
  { icon: FileText, tab: "gst", title: "GST Compliance", desc: "Complete GST lifecycle management — registration, return filing, amendments, E-Way bills, and ITC advisory." },
  { icon: Calculator, tab: "income-tax", title: "Income Tax", desc: "ITR filing for individuals and businesses, TDS returns, tax planning, notice handling, and PAN card services." },
  { icon: BookOpen, tab: "accounting", title: "Accounting & Bookkeeping", desc: "Accurate books, balance sheets, P&L statements, cash flow reports, payroll processing, and MIS reports." },
  { icon: ShieldCheck, tab: "audit", title: "Audit Support", desc: "Internal audit, GST audit assistance, concurrent audit support, tax audit coordination, and compliance audit." },
  { icon: Building2, tab: "registration", title: "Business Registration", desc: "Private Limited, LLP, OPC, Partnership, Trust/Society — formation, MOA/AOA filing, DIN, DSC, and annual compliance." },
  { icon: Lightbulb, tab: "consultancy", title: "Tax Consultancy", desc: "Strategic tax planning, tax-saving advisory, compliance management, and end-to-end business financial guidance." },
  { icon: TrendingUp, tab: "financial", title: "Financial Services", desc: "CMA reports, project reports for bank loans, projected financials, and working capital assessment for businesses." },
  { icon: Award, tab: "certification", title: "Certification Services", desc: "Net worth certificates, CA certificates, income certificates, and fund utilisation certificates." },
  { icon: LayoutGrid, tab: "other", title: "Other Services", desc: "Property valuation reports, loan documentation, insurance advisory, and investment planning guidance." },
];

const whys = [
  { icon: Lock, title: "Complete Confidentiality", desc: "Your financial data is handled with absolute discretion and professional integrity." },
  { icon: Users, title: "Qualified Professional Team", desc: "Registered tax practitioners with deep knowledge of GST law, Income Tax Act, and Companies Act." },
  { icon: Clock, title: "Timely & Deadline-Driven", desc: "We ensure zero missed deadlines for filing, compliance, and returns across all services." },
  { icon: Layers, title: "All Services Under One Roof", desc: "From individual tax filing to company formation, everything is managed by one trusted team." },
  { icon: MessageCircle, title: "Personalised Client Approach", desc: "No cookie-cutter advice. Every client gets a solution built around their specific financial situation." },
  { icon: Handshake, title: "End-to-End Support", desc: "We stay engaged beyond filing — notices, queries, amendments, and ongoing advisory are all part of the relationship." },
];

const audiences = [
  { icon: User, title: "Individuals & Working Professionals",
    desc: "Whether you are a salaried employee, self-employed professional, business person, contractor, or anyone with a tax obligation — we handle your ITR filing, tax planning, PAN services, and income tax matters with accuracy and care.",
    cta: "Get Help", to: "/contact", tint: "#EEF2FF", iconColor: "var(--navy)", tags: ["Every Individual", "Salaried", "Professional", "Self-Employed"] },
  { icon: Briefcase, title: "Small Businesses & MSMEs",
    desc: "From small traders and labour contractors to growing MSMEs and established businesses — complete accounting, GST compliance, payroll, and financial reporting handled end to end.",
    cta: "Our Services", to: "/services", tint: "#F0FBF0", iconColor: "var(--green)", tags: ["MSME", "Contractor", "Labour Business"] },
  { icon: Building2, title: "Corporates & Business Houses",
    desc: "Company formation, statutory compliance coordination, audit support, and strategic tax consultancy for Private Limited companies, LLPs, and business groups.",
    cta: "Corporate Enquiry", to: "/corporate", tint: "#EEF2FF", iconColor: "var(--navy)", tags: ["Pvt Ltd", "LLP", "OPC"] },
] as const;

function Home() {
  return (
    <>
      {/* HERO */}
      <section className="hero-pattern relative overflow-hidden hero-section" aria-label="Hero">
        <div
          className="mx-auto max-w-[860px] px-6 text-center hero-inner"
          style={{ paddingTop: "36px", paddingBottom: "44px", marginTop: 0 }}
        >
          <style>{`
            @media (min-width: 768px){
              .hero-inner { padding-top: 56px !important; padding-bottom: 48px !important; }
              .hero-pill { margin-top: 8px !important; }
              .hero-cta { margin-bottom: 0 !important; }
              #services-overview { padding-top: 48px !important; }
            }
            @media (max-width: 767px){
              .hero-pill { margin-top: 0 !important; margin-bottom: 20px !important; }
              .hero-h1 { margin-top: 16px !important; margin-bottom: 16px !important; }
              .hero-sub { margin-top: 0 !important; margin-bottom: 28px !important; }
              .hero-cta { margin-top: 0 !important; margin-bottom: 0 !important; padding-bottom: 0 !important; }
            }
          `}</style>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, ease: "easeOut" }}>
            <span className="hero-pill inline-block rounded-full bg-[var(--green)]/10 px-4 py-1.5 text-xs font-semibold text-[var(--green)]">
              GST • Income Tax • Accounting • Business Compliance
            </span>
            <h1 className="hero-h1 mt-5 font-display text-4xl font-extrabold leading-[1.05] tracking-tight md:text-6xl">
              <span className="text-[var(--navy)]">Right Place,</span><br />
              <span className="text-[var(--green)]">Right Advice.</span>
            </h1>
            <p className="hero-sub mx-auto mt-6 max-w-2xl text-base leading-relaxed text-[var(--muted-ink)] md:text-lg">
              Professional tax practitioners and financial consultants helping individuals, salaried professionals, MSMEs, and businesses across India with GST compliance, income tax filing, accounting, and complete business registration — all under one roof.
            </p>
            <div className="hero-cta mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row" style={{ gap: "16px" }}>
              <a href={waUrl("Hello Fintax Services, I would like a free consultation.")} target="_blank" rel="noopener noreferrer"
                 className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[var(--green)] px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-[var(--green-dark)] sm:w-auto">
                <MessageCircle size={18} /> WhatsApp Us
              </a>
              <a href="#services-overview"
                 className="inline-flex w-full items-center justify-center gap-2 rounded-lg border-2 border-[var(--navy)] px-5 py-3 text-sm font-semibold text-[var(--navy)] transition hover:bg-[var(--navy)] hover:text-white sm:w-auto">
                Explore Services
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* SERVICES OVERVIEW */}
      <section id="services-overview" className="py-20" aria-label="Services overview">
        <div className="mx-auto max-w-7xl px-6 md:px-10">
          <FadeUp className="text-center">
            <SectionLabel>What we do</SectionLabel>
            <h2 className="mt-3 font-display text-3xl font-extrabold md:text-4xl">Comprehensive Business Services Under One Roof</h2>
          </FadeUp>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {services.map((s, i) => {
              const band = i < 5 ? "var(--navy)" : "var(--green)";
              return (
                <FadeUp key={s.title} delay={i * 0.04}>
                  <Link to="/services" search={{ tab: s.tab }}
                    className="service-card group flex h-full flex-col overflow-hidden rounded-[10px] bg-white card-shadow"
                    style={{ willChange: "transform" }}>
                    <div className="flex h-14 w-full items-center justify-center" style={{ background: band }}>
                      <s.icon className="text-white" size={24} />
                    </div>
                    <div className="flex flex-1 flex-col p-5">
                      <h3 className="font-display text-base font-bold text-[var(--green)]">{s.title}</h3>
                      <p className="mt-2 flex-1 text-sm text-[var(--muted-ink)]" style={{ lineHeight: 1.6 }}>{s.desc}</p>
                      <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-[var(--green)] group-hover:gap-2 transition-all">
                        Learn More <ArrowRight size={14} />
                      </span>
                    </div>
                  </Link>
                </FadeUp>
              );
            })}
          </div>
        </div>
      </section>

      {/* WHY CHOOSE */}
      <section className="bg-[var(--alt)] py-20" aria-label="Why choose Fintax">
        <div className="mx-auto max-w-7xl px-6 md:px-10">
          <FadeUp className="text-center">
            <SectionLabel>Why Fintax</SectionLabel>
            <h2 className="mt-3 font-display text-3xl font-extrabold md:text-4xl">Why Clients Trust Fintax Services</h2>
          </FadeUp>
          <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {whys.map((w, i) => (
              <FadeUp key={w.title} delay={i * 0.04}>
                <div className="flex gap-4">
                  <w.icon className="shrink-0 text-[var(--green)]" size={28} />
                  <div>
                    <h3 className="font-display text-base font-bold">{w.title}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-[var(--muted-ink)]">{w.desc}</p>
                  </div>
                </div>
              </FadeUp>
            ))}
          </div>
        </div>
      </section>

      {/* WHO WE SERVE */}
      <section className="py-20" aria-label="Who we serve">
        <div className="mx-auto max-w-7xl px-6 md:px-10">
          <FadeUp className="text-center">
            <SectionLabel>Who we help</SectionLabel>
            <h2 className="mt-3 font-display text-3xl font-extrabold md:text-4xl">Built for Every Stage of Your Financial Journey</h2>
          </FadeUp>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {audiences.map((a, i) => (
              <FadeUp key={a.title} delay={i * 0.05}>
                <div className="service-card flex h-full flex-col rounded-[10px] bg-white p-7 text-center card-shadow">
                  <div
                    className="mx-auto flex h-20 w-20 items-center justify-center rounded-full"
                    style={{ background: a.tint }}
                  >
                    <a.icon size={40} style={{ color: a.iconColor }} />
                  </div>
                  <div className="mt-4 flex flex-wrap justify-center gap-2">
                    {a.tags.map((t) => (
                      <motion.span
                        key={t}
                        whileHover={{ scale: 1.06, backgroundColor: "#1A2B5F", color: "#fff" }}
                        transition={{ duration: 0.18 }}
                        className="cursor-default rounded-full bg-[var(--green)]/10 px-3 py-1 text-xs font-medium text-[var(--green)]"
                      >
                        {t}
                      </motion.span>
                    ))}
                  </div>
                  <h3 className="mt-4 font-display text-lg font-bold">{a.title}</h3>
                  <p className="mt-2 flex-1 text-sm leading-relaxed text-[var(--muted-ink)]">{a.desc}</p>
                  <Link to={a.to} className="mt-4 inline-flex items-center justify-center gap-1 text-sm font-semibold text-[var(--green)]">
                    {a.cta} <ArrowRight size={14} />
                  </Link>
                </div>
              </FadeUp>
            ))}
          </div>
        </div>
      </section>

      {/* VISION */}
      <VisionSection />

      {/* DETAILED TABS */}
      <section id="services-detail" className="bg-[var(--alt)] py-20" aria-label="Detailed services">
        <div className="mx-auto max-w-7xl px-6 md:px-10">
          <FadeUp className="text-center">
            <SectionLabel>Explore</SectionLabel>
            <h2 className="mt-3 font-display text-3xl font-extrabold md:text-4xl">Explore Our Services in Detail</h2>
          </FadeUp>
          <div className="mt-10"><ServiceTabs /><div className="md:hidden"><AccordionServices /></div></div>
        </div>
      </section>

      {/* TEAM */}
      <section className="py-20" aria-label="Our team">
        <div className="mx-auto max-w-7xl px-6 md:px-10">
          <FadeUp className="text-center">
            <h2 className="font-display text-3xl font-extrabold md:text-4xl">Meet Our Team</h2>
          </FadeUp>
          <div className="mt-12"><TeamCards /></div>
        </div>
      </section>

      {/* REVIEWS */}
      <Reviews />

      {/* CTA BANNER */}
      <section className="bg-[var(--navy)] py-16" aria-label="Call to action">
        <div className="mx-auto max-w-5xl px-6 text-center md:px-10">
          <h2 className="font-display text-3xl font-extrabold text-white md:text-4xl">Ready to Simplify Your Taxes and Grow Your Business?</h2>
          <p className="mx-auto mt-4 max-w-3xl text-base text-blue-100">
            Talk to our team today. No jargon, no complications — just honest, reliable financial guidance tailored to your needs.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <a href={waUrl("Hello Fintax Services, I need help with my taxes.")} target="_blank" rel="noopener noreferrer"
               className="inline-flex items-center gap-2 rounded-lg bg-[var(--green)] px-5 py-3 text-sm font-semibold text-white hover:bg-[var(--green-dark)]">
              <MessageCircle size={18} /> WhatsApp Us Now
            </a>
            <a href={`tel:${PHONE}`}
               className="inline-flex items-center gap-2 rounded-lg border-2 border-white px-5 py-3 text-sm font-semibold text-white hover:bg-white hover:text-[var(--navy)]">
              <Phone size={18} /> Call Us Now
            </a>
          </div>
        </div>
      </section>

      {/* CONTACT + MAP */}
      <section className="py-20" aria-label="Office contact and map">
        <div className="mx-auto grid max-w-7xl gap-10 px-6 md:grid-cols-2 md:px-10">
          <FadeUp>
            <SectionLabel>Visit us</SectionLabel>
            <h2 className="mt-3 font-display text-3xl font-extrabold md:text-4xl">Our Office</h2>
            <ul className="mt-6 space-y-4 text-sm">
              <li className="flex gap-3"><MapPin className="shrink-0 text-[var(--green)]" size={20} /><span>{ADDRESS}</span></li>
              <li className="flex gap-3"><Mail className="shrink-0 text-[var(--green)]" size={20} /><a className="hover:text-[var(--green)]" href={`mailto:${EMAIL}`}>{EMAIL}</a></li>
              <li className="flex gap-3"><Phone className="shrink-0 text-[var(--green)]" size={20} /><a className="hover:text-[var(--green)]" href={`tel:${PHONE}`}>{PHONE_DISPLAY}</a></li>
              <li className="flex gap-3"><MessageCircle className="shrink-0 text-[var(--green)]" size={20} /><a className="hover:text-[var(--green)]" href={waUrl("Hello Fintax Services, I have an enquiry.")} target="_blank" rel="noopener noreferrer">Chat on WhatsApp</a></li>
              <li className="flex gap-3"><Clock className="shrink-0 text-[var(--green)]" size={20} /><span>{HOURS}</span></li>
            </ul>
          </FadeUp>
          <FadeUp delay={0.1}>
            <div className="overflow-hidden rounded-[10px] card-shadow">
              <iframe title="Fintax Services office location" src={MAPS_EMBED} className="h-80 w-full border-0" loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
            </div>
          </FadeUp>
        </div>
      </section>
    </>
  );
}
