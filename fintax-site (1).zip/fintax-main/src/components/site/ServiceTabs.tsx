import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check } from "lucide-react";

export type TabItem = { title: string; desc?: string };
export type TabDef = { id: string; label: string; items: TabItem[] };

export const TAB_DEFS: TabDef[] = [
  { id: "gst", label: "GST", items: [
    { title: "GST Registration", desc: "End-to-end new GST registration including documentation, ARN tracking, and certificate delivery for proprietors, partnerships, and companies." },
    { title: "GST Return Filing (GSTR-1, 3B, 9, 9C)", desc: "Monthly, quarterly, and annual return filing with reconciliation against GSTR-2B and books to maximise compliance accuracy." },
    { title: "GST Amendment & Rectification", desc: "Core and non-core amendments to registration details and corrections in already-filed returns." },
    { title: "GST E-Way Bill Management", desc: "E-way bill generation, cancellation, and consolidation support for goods movement across states." },
    { title: "GST Audit Assistance", desc: "Preparation of records, reconciliations, and supporting documents for GST audit by the department." },
    { title: "Input Tax Credit (ITC) Advisory", desc: "ITC eligibility review, reconciliation, blocked credit identification, and reversal computations." },
    { title: "GST Compliance Consultancy", desc: "Ongoing advisory on rate notifications, place-of-supply, RCM, and sector-specific GST queries." },
    { title: "Internal Audit Support", desc: "Periodic review of GST positions, return data, and documentation as part of internal control." },
    { title: "GST Notice Handling & Response", desc: "Drafting structured replies to ASMT, DRC, and other GST notices and assisting in personal hearings." },
  ]},
  { id: "income-tax", label: "Income Tax", items: [
    { title: "ITR Filing (ITR-1 to ITR-7)", desc: "Accurate preparation and filing of every ITR form for salaried individuals, businesses, firms, trusts, and companies." },
    { title: "TDS Return Filing (24Q, 26Q)", desc: "Quarterly TDS return preparation, correction statements, and Form 16/16A issuance." },
    { title: "Strategic Tax Planning", desc: "Year-round planning to legitimately reduce tax liability through deductions, exemptions, and structure." },
    { title: "Tax-Efficient Filing Advisory", desc: "Old vs new regime comparison, capital gains optimisation, and salary structuring guidance." },
    { title: "Income Tax Notice Reply & Representation", desc: "Drafting replies to 143(1), 139(9), 148, and 245 notices and representation before the Assessing Officer." },
    { title: "PAN Card Application & Corrections", desc: "New PAN, corrections, reprint, and Aadhaar-PAN linking assistance." },
    { title: "Re-assessment & Appeal Assistance", desc: "Support in re-assessment proceedings, appeal drafting before CIT(A), and case documentation." },
    { title: "Advance Tax Calculation & Advisory", desc: "Quarterly advance tax computation and reminders to avoid 234B/234C interest." },
    { title: "Capital Gain Tax Advisory", desc: "Computation and planning for short-term and long-term capital gains on property, equity, and other assets with exemption guidance." },
    { title: "Form 15CA / 15CB Assistance", desc: "Coordination and filing support for foreign remittance certificates." },
  ]},
  { id: "accounting", label: "Accounting", items: [
    { title: "Daily Bookkeeping & Ledger Management", desc: "Day-to-day recording of transactions in Tally or similar systems with periodic review." },
    { title: "Balance Sheet Preparation", desc: "Year-end balance sheet preparation in compliance with applicable accounting standards." },
    { title: "Profit & Loss (P&L) Account", desc: "Monthly and annual P&L reporting for performance tracking and statutory filing." },
    { title: "Cash Flow Statement", desc: "Cash flow analysis to monitor liquidity and operating, investing, and financing activities." },
    { title: "MIS Reporting", desc: "Customised management information reports for owners and management decision-making." },
    { title: "Payroll Processing", desc: "Salary calculation, payslip generation, PF/ESI/PT/TDS computation, and disbursement support." },
    { title: "Accounts System Setup & Management", desc: "Setting up chart of accounts, masters, and templates for new and growing businesses." },
    { title: "Bank Reconciliation", desc: "Periodic reconciliation of bank statements with books to ensure cash accuracy." },
    { title: "Debtors & Creditors Management", desc: "Outstanding statements, ageing analysis, and follow-up reports for receivables and payables." },
  ]},

  { id: "audit", label: "Audit Support", items: [
    { title: "Internal Audit Support", desc: "Process review and risk-based testing of internal controls across functions." },
    { title: "GST Audit Assistance", desc: "Data preparation and reconciliation support for departmental and self-certified GST audits." },
    { title: "Stock Audit", desc: "Physical verification and valuation support for inventory across locations." },
    { title: "Tax Audit Coordination", desc: "Coordination with the auditor for clause-wise data, Form 3CD annexures, and back-up." },
    { title: "Concurrent Audit Support", desc: "Ongoing transactional review support for organisations needing real-time audit input." },
    { title: "Compliance Audit", desc: "Review of statutory and regulatory compliance status across applicable laws." },
    { title: "Statutory Audit Coordination", desc: "Preparation of schedules, confirmations, and audit working papers for the statutory auditor." },
    { title: "Audit Report Preparation Assistance", desc: "Drafting support for management responses and audit closure documentation." },
  ]},
  { id: "registration", label: "Business Registration", items: [
    { title: "Private Limited Company Registration", desc: "End-to-end Pvt Ltd incorporation including name reservation, SPICe+, AGILE-PRO, and PAN/TAN." },
    { title: "LLP Formation", desc: "LLP incorporation with FiLLiP, agreement drafting, and post-registration compliance setup." },
    { title: "One Person Company (OPC) Registration", desc: "OPC formation for single-founder businesses, including nominee documentation." },
    { title: "Partnership Firm Registration", desc: "Drafting of partnership deed and registration with the Registrar of Firms." },
    { title: "Trust & Society Registration", desc: "Trust deed/society memorandum drafting and registration formalities." },
    { title: "MOA & AOA Drafting & Filing", desc: "Custom MOA and AOA drafting aligned with the business objects and structure." },
    { title: "DIN & DSC Procurement", desc: "Director Identification Number and Class-3 Digital Signature Certificate procurement." },
    { title: "Annual ROC Filing & Compliance", desc: "AOC-4, MGT-7, DIR-3 KYC, and other periodic MCA compliance filings." },
    { title: "Business Name Registration Advisory", desc: "Guidance on name availability, trademark check, and brand-aligned naming." },
    { title: "Udyam Registration (MSME)", desc: "Udyam / MSME registration to unlock priority sector benefits, subsidies, and easier credit access." },
    { title: "FSSAI License & Registration", desc: "FSSAI registration and licensing for food businesses — basic, state, and central category support." },
    { title: "Import Export Licence (IEC)", desc: "DGFT IEC application and modification support for businesses dealing in cross-border trade." },
  ]},
  { id: "consultancy", label: "Tax Consultancy", items: [
    { title: "Strategic Tax Planning", desc: "Long-horizon tax strategy mapped to business growth, ownership, and reinvestment plans." },
    { title: "Tax-Saving Advisory", desc: "Identifying legitimate deductions, exemptions, and incentive schemes for individuals and businesses." },
    { title: "Business & Financial Advisory", desc: "Practical advisory on cash flow, working capital, costing, and profitability improvement." },
    { title: "Compliance Management", desc: "Single-point coordination across direct tax, indirect tax, and corporate compliance calendars." },
    { title: "Guidance & Ongoing Support", desc: "Year-round access to your tax practitioner for queries, notices, and decision support." },
    { title: "Multi-Year Tax Strategy", desc: "Planning that accounts for upcoming regulatory changes and business transitions." },
    { title: "Loan & Finance Documentation Support", desc: "Preparation of projections, CMA data, and financial documents for bank borrowings." },
    { title: "Business Structuring Advisory", desc: "Choosing and migrating to the right legal structure as the business scales." },
    { title: "Complete Solution Under One Roof", desc: "Tax, accounting, audit support, and registration handled by one accountable team." },
  ]},
  { id: "financial", label: "Financial Services", items: [
    { title: "CMA Reports (Credit Monitoring Arrangement)", desc: "Bank-ready CMA data preparation aligned with RBI norms for working capital and term loan proposals." },
    { title: "Project Reports for Bank Loans", desc: "Detailed project reports covering technical, financial, and commercial feasibility for loan sanctioning." },
    { title: "Projected Financial Statements", desc: "Projected P&L, balance sheet, and cash flow for funding, tenders, and strategic planning." },
    { title: "Working Capital Assessment Reports", desc: "Assessment of working capital limits, drawing power, and stock-statement requirements for banking facilities." },
    { title: "Financial Planning & Structuring", desc: "Capital structure, debt-equity mix, and funding strategy guidance for businesses at every growth stage." },
  ]},
  { id: "certification", label: "Certification", items: [
    { title: "Net Worth Certificates", desc: "Certified net worth statements for visa, tender, and credit applications based on verified financials." },
    { title: "CA Certificates (Coordination & Assistance)", desc: "Coordination and documentation assistance for various CA-issued certificates required by banks, regulators, and authorities." },
    { title: "Income Certificates", desc: "Income certification for loans, scholarships, and government schemes — backed by ITR and supporting records." },
    { title: "Fund Utilisation Certificates", desc: "Certificates confirming end-use of grants, loans, and CSR funds aligned with sanctioned purposes." },
    { title: "Turnover Certificates", desc: "Turnover certification for tenders, bank limits, and regulatory submissions, reconciled with books and GST." },
  ]},
  { id: "other", label: "Other Services", items: [
    { title: "Property Valuation Reports", desc: "Coordination for property valuation reports for loan, sale, and capital gains computation purposes." },
    { title: "Loan Documentation Assistance", desc: "End-to-end assistance with loan applications, KYC, financials, and supporting documents for banks and NBFCs." },
    { title: "Insurance Advisory", desc: "Need-based guidance on life, health, and general insurance products to protect family and business interests." },
    { title: "Investment Planning Guidance", desc: "Goal-linked investment planning across traditional and modern instruments with a tax-aware lens." },
  ]},
];

export function ServiceTabs({
  detailed = false,
  active: activeProp,
  onActiveChange,
}: {
  detailed?: boolean;
  active?: string;
  onActiveChange?: (id: string) => void;
}) {
  const [activeState, setActiveState] = useState(TAB_DEFS[0].id);
  const active = activeProp ?? activeState;
  const setActive = (id: string) => {
    if (onActiveChange) onActiveChange(id);
    else setActiveState(id);
  };
  const current = TAB_DEFS.find((t) => t.id === active) ?? TAB_DEFS[0];

  return (
    <div className="hidden w-full max-w-full md:block">
      <div className="tab-bar-scroll mb-6 flex w-full max-w-full gap-2 border-b border-[var(--border)] pb-px">
        {TAB_DEFS.map((t) => (
          <button
            key={t.id}
            onClick={() => setActive(t.id)}
            className={`tab-item relative transition-colors ${
              active === t.id ? "font-bold text-[var(--navy)]" : "font-medium text-[var(--muted-ink)] hover:text-[var(--navy)]"
            }`}
          >
            {t.label}
            {active === t.id && (
              <motion.span
                layoutId="tabIndicator"
                className="absolute -bottom-px left-0 right-0 h-0.5 bg-[var(--green)]"
                transition={{ type: "spring", stiffness: 400, damping: 32 }}
              />
            )}
          </button>
        ))}
      </div>
      <div className="w-full max-w-full overflow-hidden rounded-[10px] bg-white p-6 card-shadow md:p-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={current.id}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className={`grid w-full max-w-full grid-cols-1 gap-x-8 md:grid-cols-2 ${detailed ? "gap-y-6" : "gap-y-4"}`}
          >
            {current.items.map((it) => (
              <div key={it.title} className="flex min-w-0 max-w-full gap-3">
                <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[var(--green)]/10 text-[var(--green)]">
                  <Check size={14} strokeWidth={3} />
                </span>
                <div className="min-w-0 max-w-full">
                  <div className="font-semibold text-[var(--navy)]" style={{ overflowWrap: "break-word", wordBreak: "break-word" }}>{it.title}</div>
                  {detailed && it.desc && (
                    <p className="mt-1 text-sm leading-relaxed text-[var(--muted-ink)]" style={{ overflowWrap: "break-word", wordBreak: "break-word" }}>{it.desc}</p>
                  )}
                </div>
              </div>
            ))}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
