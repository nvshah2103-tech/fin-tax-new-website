import { useState } from "react";
import { MessageCircle, Phone } from "lucide-react";
import { PHONE, waUrl } from "@/lib/site";

export function FloatingButtons() {
  const [hoverWa, setHoverWa] = useState(false);
  const [hoverCall, setHoverCall] = useState(false);
  return (
    <>
      <a
        href={`tel:${PHONE}`}
        onMouseEnter={() => setHoverCall(true)} onMouseLeave={() => setHoverCall(false)}
        className="fixed z-[9999] flex h-[52px] items-center gap-2 overflow-hidden rounded-full bg-[var(--navy)] pl-4 pr-4 text-white shadow-lg transition-all animate-pulse-ring-slow"
        style={{ bottom: 80, right: 16, width: hoverCall ? 160 : 52 }}
        aria-label="Call Fintax Services"
      >
        <Phone size={24} className="shrink-0" />
        <span className={`whitespace-nowrap text-sm font-semibold transition-opacity ${hoverCall ? "opacity-100" : "opacity-0"}`}>Call Us</span>
      </a>
      <a
        href={waUrl("Hello Fintax Services, I have an enquiry.")}
        target="_blank" rel="noopener noreferrer"
        onMouseEnter={() => setHoverWa(true)} onMouseLeave={() => setHoverWa(false)}
        className="fixed z-[9999] flex h-[52px] items-center gap-2 overflow-hidden rounded-full pl-4 pr-4 text-white shadow-lg transition-all animate-pulse-ring"
        style={{ bottom: 20, right: 16, width: hoverWa ? 180 : 52, backgroundColor: "#25D366" }}
        aria-label="Chat with us on WhatsApp"
      >
        <MessageCircle size={24} className="shrink-0" />
        <span className={`whitespace-nowrap text-sm font-semibold transition-opacity ${hoverWa ? "opacity-100" : "opacity-0"}`}>Chat with Us</span>
      </a>
    </>
  );
}
