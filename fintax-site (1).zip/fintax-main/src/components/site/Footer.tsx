import { Link } from "@tanstack/react-router";
import { MessageCircle } from "lucide-react";
import logo from "@/assets/fintax-logo.jpeg";
import { ADDRESS, EMAIL, HOURS, PHONE, PHONE_DISPLAY, waUrl } from "@/lib/site";

export function Footer() {
  return (
    <footer className="bg-[var(--navy-deep)] text-white" aria-label="Site footer">
      <div className="mx-auto max-w-7xl px-6 py-14 md:px-10">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-3">
              <img src={logo} alt="Fintax Services logo" className="h-12 w-12 rounded-full bg-white object-cover" />
              <div>
                <div className="font-display text-lg font-extrabold tracking-wide">FINTAX</div>
                <div className="-mt-1 text-[10px] font-semibold tracking-[0.25em] text-[var(--green)]">SERVICES</div>
              </div>
            </div>
            <p className="mt-4 text-sm text-white/70 leading-relaxed">
              Professional Tax Practitioners and Financial Consultants helping individuals, MSMEs, and businesses across India with all their tax, accounting, and compliance needs.
            </p>
          </div>

          <div>
            <h3 className="font-display text-sm font-bold uppercase tracking-widest text-white">Quick Links</h3>
            <ul className="mt-4 space-y-2 text-sm text-white/70">
              {[
                ["/", "Home"], ["/services", "Services"], ["/about", "About Us"],
                ["/corporate", "For Businesses"], ["/contact", "Contact"],
              ].map(([to, label]) => (
                <li key={to}><Link to={to} className="hover:text-[var(--green)]">{label}</Link></li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-display text-sm font-bold uppercase tracking-widest text-white">Our Services</h3>
            <ul className="mt-4 space-y-2 text-sm text-white/70">
              {[
                ["gst", "GST Compliance"],
                ["income-tax", "Income Tax Filing"],
                ["accounting", "Accounting & Bookkeeping"],
                ["audit", "Audit Support"],
                ["registration", "Business Registration"],
                ["consultancy", "Tax Consultancy"],
                ["financial", "Financial Services"],
                ["certification", "Certification"],
                ["other", "Other Services"],
              ].map(([tab, label]) => (
                <li key={tab}>
                  <Link to="/services" search={{ tab }} className="hover:text-[var(--green)]">{label}</Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-display text-sm font-bold uppercase tracking-widest text-white">Contact</h3>
            <ul className="mt-4 space-y-3 text-sm text-white/70">
              <li>{ADDRESS}</li>
              <li><a href={`mailto:${EMAIL}`} className="hover:text-[var(--green)]">{EMAIL}</a></li>
              <li><a href={`tel:${PHONE}`} className="hover:text-[var(--green)]">{PHONE_DISPLAY}</a></li>
              <li>
                <a href={waUrl("Hello Fintax Services, I have an enquiry.")} target="_blank" rel="noopener noreferrer"
                   className="inline-flex items-center gap-2 hover:text-[var(--green)]">
                  <MessageCircle size={16} /> Chat on WhatsApp
                </a>
              </li>
              <li>{HOURS}</li>
            </ul>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-6 py-5 text-xs text-white/60 md:flex-row md:items-center md:justify-between md:px-10">
          <span>© 2025 Fintax Services. All Rights Reserved.</span>
          <span>Tax Consultants | Gujarat, India</span>
        </div>
      </div>
    </footer>
  );
}
