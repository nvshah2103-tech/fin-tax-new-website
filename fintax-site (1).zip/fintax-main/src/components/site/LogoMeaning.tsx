import { motion } from "framer-motion";
import { CheckCheck, Circle, ShieldCheck } from "lucide-react";
import logo from "@/assets/fintax-logo.jpeg";
import { FadeUp, SectionLabel } from "@/components/site/Section";

type Card = {
  icon: React.ReactNode;
  title: string;
  titleColor: string;
  desc: string;
};

const cards: Card[] = [
  {
    icon: (
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full" style={{ backgroundColor: "#EEF1F8" }}>
        <span className="font-display text-[28px] font-extrabold leading-none" style={{ color: "#1A2B5F" }}>F</span>
      </div>
    ),
    title: "F — Stands for FinTax",
    titleColor: "#1A2B5F",
    desc: "The bold F lettermark at the heart of the logo is the foundation of our identity — representing the firm, our name, and our purpose.",
  },
  {
    icon: (
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full" style={{ backgroundColor: "#E8F5E9" }}>
        <CheckCheck size={28} style={{ color: "#2D7A3A" }} />
      </div>
    ),
    title: "Green Reverse Tick — Verification",
    titleColor: "#2D7A3A",
    desc: "The distinctive green reverse tick symbolises our verification process — every calculation, every filing, every document is checked and confirmed before submission.",
  },
  {
    icon: (
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full" style={{ backgroundColor: "#EEF1F8" }}>
        <Circle size={28} style={{ color: "#1A2B5F" }} />
      </div>
    ),
    title: "Circle — Privacy & Confidentiality",
    titleColor: "#1A2B5F",
    desc: "The enclosing circle represents a protected space — your financial information stays within a secure, confidential boundary. Always.",
  },
  {
    icon: (
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full" style={{ backgroundColor: "#EEF1F8" }}>
        <ShieldCheck size={28} style={{ color: "#1A2B5F" }} />
      </div>
    ),
    title: "Blue Colour — Trust & Integrity",
    titleColor: "#1A2B5F",
    desc: "Navy blue is the colour of trust, reliability, and professionalism — the values we bring to every client relationship, every single day.",
  },
];

export function LogoMeaning() {
  return (
    <section className="py-20" style={{ backgroundColor: "#F7F9FC" }} aria-label="What our logo represents">
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        <FadeUp className="text-center">
          <SectionLabel>Brand Identity</SectionLabel>
          <h2 className="mt-3 font-display text-3xl font-extrabold md:text-4xl">What Our Logo Represents</h2>
          <p className="mx-auto mt-4 max-w-2xl text-base text-[var(--muted-ink)]">
            Every element of the Fintax Services logo carries a deliberate meaning — a reflection of our values and our commitment to our clients.
          </p>
        </FadeUp>

        <div className="mt-12 grid items-center gap-10 md:grid-cols-2">
          <FadeUp>
            <div className="flex justify-center">
              <img
                src={logo}
                alt="Fintax Services logo mark"
                width={280}
                height={280}
                loading="lazy"
                className="w-full max-w-[280px] object-contain"
              />
            </div>
          </FadeUp>

          <div className="flex flex-col gap-4">
            {cards.map((c, i) => (
              <motion.div
                key={c.title}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.4, ease: "easeOut", delay: i * 0.1 }}
                className="flex items-start gap-4 rounded-[10px] bg-white p-5 card-shadow"
                style={{ willChange: "transform" }}
              >
                {c.icon}
                <div>
                  <h3 className="font-display text-base font-bold" style={{ color: c.titleColor }}>
                    {c.title}
                  </h3>
                  <p className="mt-1 text-sm leading-relaxed text-[var(--muted-ink)]">{c.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
