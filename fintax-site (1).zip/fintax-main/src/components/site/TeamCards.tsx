import { Scale, Landmark, ClipboardList, BarChart3, Building } from "lucide-react";
import majid from "@/assets/new_photo1.jpeg";
import noman from "@/assets/nomankhan-pathan.jpeg";
import manishJain from "@/assets/manish-jain.jpg";
import abdulsamadShaikh from "@/assets/abdulsamad-shaikh.jpg";
import parthPatel from "@/assets/parth-patel.jpg";
import akhileshPrajapati from "@/assets/akhilesh-prajapati.jpg";

type Partner = {
  name: string;
  role: string;
  designation: string;
  short: string;
  long: string;
  tags: string[];
  img: string;
  alt: string;
};

const PARTNERS: Partner[] = [
  {
    name: "Nomankhan Pathan",
    role: "Founder — Fintax Services",
    designation: "Professional Tax Practitioner",
    short: "Registered Tax Practitioner with deep expertise in Income Tax, GST compliance, and comprehensive business advisory services across India.",
    long: " Nomankhan leads tax strategy, compliance, and representation for the firm — handling everything from individual ITRs to complex GST and notice matters.",
    tags: ["Income Tax", "GST", "Tax Planning", "Advisory"],
    img: noman,
    alt: "Nomankhan Pathan, Founder of Fintax Services",
  },
  {
    name: "Majidkhan Pathan",
    role: "Co-Founder — Fintax Services",
    designation: "Professional Financial Advisor",
    short: "Dedicated to delivering practical, client-focused financial and tax solutions for individuals and businesses across India.",
    long: " With a strong commercial background, Majidkhan oversees client accounting, MSME advisory, and day-to-day client coordination — ensuring every engagement is handled with diligence and care.",
    tags: ["Accounting", "GST Compliance", "MSME Advisory"],
    img: majid,
    alt: "Majidkhan Pathan, Co-Founder of Fintax Services",
  },
];

type Consultant = {
  name: string;
  title: string;
  bio: string;
  initials: string;
  img: string;
};

const CONSULTANTS: Consultant[] = [
  {
    name: "CA Manish Jain",
    title: "Tax & Expert Advisor",
    bio: "A Chartered Accountant with over 15 years of professional experience, he brings comprehensive guidance across direct and indirect tax matters, helping businesses and individuals make sound financial decisions with complete confidence.",
    initials: "MJ",
    img: manishJain,
  },
  {
    name: "CA Abdulsamad Shaikh",
    title: "Audit & Compliance Specialist",
    bio: "Chartered Accountant with over 6 years of experience in statutory audit, concurrent audit, and financial compliance — ensuring every engagement meets the highest standards of accuracy and regulatory adherence.",
    initials: "AS",
    img: abdulsamadShaikh,
  },
  {
    name: "CS Parth Patel",
    title: "Corporate Law & Advisory",
    bio: "Qualified Company Secretary with over 6 years of expertise in corporate law, ROC compliance, company incorporation, and secretarial governance for businesses of all structures.",
    initials: "PP",
    img: parthPatel,
  },
  {
    name: "Akhilesh Prajapati",
    title: "Accounting Head",
    bio: "Accounting professional with over 8 years of hands-on experience leading financial reporting, bookkeeping, payroll processing, and MIS reporting across diverse industries and business sizes.",
    initials: "AP",
    img: akhileshPrajapati,
  },
];

const EXTENDED = [
  { icon: Scale, label: "Legal Advisor" },
  { icon: Landmark, label: "Government Approved Valuer" },
  { icon: ClipboardList, label: "Compliance Associates" },
  { icon: BarChart3, label: "Financial Analysts" },
  { icon: Building, label: "Business Registration Executives" },
];

export function TeamCards({ expanded = false }: { expanded?: boolean }) {
  return (
    <div className="space-y-16">
      {/* FOUNDERS */}
      <div className="mx-auto grid max-w-4xl gap-6 md:grid-cols-2">
        {PARTNERS.map((p) => (
          <div key={p.name} className="rounded-[10px] bg-white p-8 text-center card-shadow transition-transform hover:-translate-y-1">
            <img
              src={p.img}
              alt={p.alt}
              width={256}
              height={256}
              loading="lazy"
              className="mx-auto h-32 w-32 rounded-full object-cover object-top ring-4 ring-[var(--alt)]"
            />
            <h3 className="mt-4 font-display text-xl font-bold">{p.name}</h3>
            <div className="text-sm text-[var(--muted-ink)]">{p.role}</div>
            <div
              className="mt-2 inline-block"
              style={{
                background: "#E8F5E9",
                color: "#2D7A3A",
                borderRadius: "20px",
                padding: "4px 14px",
                fontFamily: "Inter, sans-serif",
                fontWeight: 500,
                fontSize: "13px",
              }}
            >
              {p.designation}
            </div>
            <p className="mt-4 text-sm leading-relaxed text-[var(--foreground)]">
              {p.short}
              {expanded && p.long}
            </p>
            {expanded && (
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                {p.tags.map((t) => (
                  <span key={t} className="rounded-full bg-[var(--green)]/10 px-3 py-1 text-xs font-medium text-[var(--green)]">
                    {t}
                  </span>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* CONSULTING TEAM */}
      <div>
        <h3
          style={{
            fontFamily: "Inter, sans-serif",
            fontWeight: 600,
            fontSize: "18px",
            color: "#6B7280",
            textAlign: "center",
            marginTop: "48px",
          }}
        >
          Our Expert Consulting Team
        </h3>
        <div style={{ width: "40px", height: "2px", background: "#2D7A3A", margin: "12px auto 32px" }} />
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {CONSULTANTS.map((c) => (
            <div
              key={c.name}
              className="bg-white text-center card-shadow"
              style={{ borderRadius: "12px", padding: "24px" }}
            >
              <img
                src={c.img}
                alt={c.name}
                loading="lazy"
                style={{
                  width: "96px",
                  height: "96px",
                  borderRadius: "50%",
                  objectFit: "cover",
                  objectPosition: "center top",
                  display: "block",
                  margin: "0 auto 16px auto",
                  boxShadow: "0 4px 12px rgba(0,0,0,0.10)",
                  border: "3px solid #E8F5E9",
                }}
              />
              <h4
                className="mt-4"
                style={{ fontFamily: "Montserrat, sans-serif", fontWeight: 700, fontSize: "16px", color: "#1A2B5F" }}
              >
                {c.name}
              </h4>
              <div
                className="mt-2 inline-block"
                style={{
                  background: "#EEF2FF",
                  color: "#1A2B5F",
                  borderRadius: "20px",
                  padding: "4px 14px",
                  fontFamily: "Inter, sans-serif",
                  fontWeight: 500,
                  fontSize: "12px",
                }}
              >
                {c.title}
              </div>
              <p className="mt-3 text-sm leading-relaxed text-[var(--muted-ink)]">{c.bio}</p>
            </div>
          ))}
        </div>
      </div>

      {/* EXTENDED TEAM */}
      <div style={{ background: "#F7F9FC", padding: "32px", borderRadius: "12px" }}>
        <h3
          style={{
            fontFamily: "Inter, sans-serif",
            fontWeight: 600,
            fontSize: "15px",
            color: "#6B7280",
            textAlign: "center",
          }}
        >
          Our Extended Team of Professionals
        </h3>
        <div className="mt-5 flex flex-wrap justify-center" style={{ gap: "12px" }}>
          {EXTENDED.map((e) => (
            <span
              key={e.label}
              className="inline-flex items-center"
              style={{
                background: "#FFFFFF",
                border: "1px solid #E5E7EB",
                borderRadius: "20px",
                padding: "8px 18px",
                fontFamily: "Inter, sans-serif",
                fontWeight: 500,
                fontSize: "14px",
                color: "#1A2B5F",
                gap: "8px",
              }}
            >
              <e.icon size={12} style={{ color: "#2D7A3A" }} />
              {e.label}
            </span>
          ))}
        </div>
        <p
          className="mt-4"
          style={{
            fontFamily: "Inter, sans-serif",
            fontWeight: 400,
            fontSize: "13px",
            color: "#9CA3AF",
            textAlign: "center",
          }}
        >
          A complete team ensuring every client receives end-to-end support across all financial, legal, and compliance domains.
        </p>
      </div>
    </div>
  );
}
