import { useState } from "react";
import {
  ChevronDown, FileText, Calculator, BookOpen, ShieldCheck,
  Building2, Lightbulb, TrendingUp, Award, LayoutGrid,
} from "lucide-react";
import { TAB_DEFS } from "./ServiceTabs";

const ICONS: Record<string, typeof FileText> = {
  gst: FileText,
  "income-tax": Calculator,
  accounting: BookOpen,
  audit: ShieldCheck,
  registration: Building2,
  consultancy: Lightbulb,
  financial: TrendingUp,
  certification: Award,
  other: LayoutGrid,
};

export function AccordionServices({
  detailed = false,
  openId,
  onOpenChange,
}: {
  detailed?: boolean;
  openId?: string;
  onOpenChange?: (id: string) => void;
}) {
  const [openState, setOpenState] = useState<string>("");
  const open = openId ?? openState;
  const setOpen = (id: string) => {
    if (onOpenChange) onOpenChange(id);
    else setOpenState(id);
  };

  return (
    <div className="w-full max-w-full overflow-hidden">
      {TAB_DEFS.map((tab) => {
        const Icon = ICONS[tab.id] ?? FileText;
        const isOpen = open === tab.id;
        return (
          <div key={tab.id} className="w-full max-w-full overflow-hidden">
            <button
              type="button"
              onClick={() => setOpen(isOpen ? "" : tab.id)}
              className="flex w-full max-w-full items-center justify-between bg-white text-left"
              style={{
                border: "none",
                borderBottom: "1px solid #E5E7EB",
                borderLeft: isOpen ? "4px solid #2D7A3A" : "4px solid transparent",
                padding: "16px 20px",
                cursor: "pointer",
              }}
              aria-expanded={isOpen}
            >
              <span className="flex items-center" style={{ gap: "12px" }}>
                <Icon size={20} style={{ color: "#2D7A3A" }} className="shrink-0" />
                <span style={{ fontWeight: 600, fontSize: "15px", color: "#1A2B5F" }}>{tab.label}</span>
              </span>
              <ChevronDown
                size={18}
                style={{ color: "#6B7280", transition: "transform 0.3s ease", transform: isOpen ? "rotate(180deg)" : "rotate(0deg)" }}
                className="shrink-0"
              />
            </button>
            <div
              className="w-full max-w-full overflow-hidden bg-white"
              style={{
                maxHeight: isOpen ? "3000px" : "0px",
                transition: "max-height 0.35s ease-in-out, padding 0.35s ease-in-out",
                padding: isOpen ? "16px 20px" : "0 20px",
              }}
            >
              {tab.items.map((it) => (
                <div
                  key={it.title}
                  className="flex w-full max-w-full"
                  style={{ alignItems: "flex-start", gap: "10px", padding: "10px 0", borderBottom: "1px solid #F3F4F6" }}
                >
                  <div className="min-w-0 flex-1">
                    <div style={{ fontWeight: 600, fontSize: "14px", color: "#2D7A3A", overflowWrap: "break-word", wordBreak: "break-word" }}>
                      {it.title}
                    </div>
                    {it.desc && (
                      <div style={{ fontWeight: 400, fontSize: "13px", color: "#6B7280", marginTop: "2px", lineHeight: 1.5, overflowWrap: "break-word", wordBreak: "break-word" }}>
                        {it.desc}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
