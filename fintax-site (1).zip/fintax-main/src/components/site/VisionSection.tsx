import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";

export function VisionSection() {
  return (
    <section
      className="relative overflow-hidden py-20"
      aria-label="Our vision"
      style={{
        background:
          "radial-gradient(ellipse at center, #243A7A 0%, #1A2B5F 60%, #15244F 100%)",
      }}
    >
      <div className="mx-auto max-w-[860px] px-6 text-center md:px-10">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.4, ease: "easeOut" }}
        >
          <div className="text-xs font-bold uppercase tracking-[0.25em] text-[var(--green)]">
            Our Vision
          </div>
          <h2 className="mt-4 font-display text-3xl font-extrabold text-white md:text-[40px] md:leading-tight">
            Financial Empowerment for Every Indian
          </h2>
          <div className="mx-auto my-6 h-[3px] w-12 bg-[var(--green)]" />
          <p className="mx-auto text-base text-white/90 md:text-lg" style={{ lineHeight: 1.8 }}>
            Every person in India deserves basic knowledge of taxation and finance.
            It helps them stay financially secure, protect their family's future, and make better
            decisions in life. When individuals become financially strong, it strengthens the
            financial stability of the nation — helping India grow stronger and more prosperous.
          </p>
          <p className="mt-6 font-semibold text-[var(--green)] md:text-xl">
            FinTax Services is moving forward with this vision.
          </p>
          <Link
            to="/contact"
            className="mt-8 inline-flex items-center gap-2 rounded-lg border-2 border-white px-5 py-3 text-sm font-semibold text-white transition hover:bg-white hover:text-[var(--navy)]"
          >
            Join Our Journey →
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
