import { useState } from "react";
import { Send, Loader2 } from "lucide-react";
import { waUrl } from "@/lib/site";

const SERVICES = ["GST Compliance","Income Tax","Accounting & Bookkeeping","Audit Support","Business Registration","Tax Consultancy","Other"];
const BUSINESS_TYPES = ["Proprietorship","Partnership","LLP","Private Limited Company","OPC","Trust / Society","Other"];
const TURNOVER = ["Below ₹20 Lakhs","₹20 Lakhs – ₹1 Crore","₹1 Crore – ₹5 Crore","Above ₹5 Crore","Prefer not to disclose"];

export function CorporateForm() {
  const [form, setForm] = useState({
    name: "", company: "", businessType: "", services: [] as string[],
    turnover: "", mobile: "", email: "", message: "", contact: "WhatsApp",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  function toggleService(s: string) {
    setForm((f) => ({ ...f, services: f.services.includes(s) ? f.services.filter(x => x !== s) : [...f.services, s] }));
  }

  function validate() {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = "Please enter your name";
    if (!form.company.trim()) e.company = "Please enter your business name";
    if (!form.businessType) e.businessType = "Please select a business type";
    if (form.services.length === 0) e.services = "Please select at least one service";
    if (!/^\d{10}$/.test(form.mobile)) e.mobile = "Please enter a valid 10-digit mobile number";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = "Please enter a valid email address";
    if (!form.contact) e.contact = "Please choose a preferred contact method";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function submit() {
    if (!validate()) return;
    setSubmitting(true);
    const text =
`Hello Fintax Services,

New Business Enquiry:

👤 Name: ${form.name}
🏢 Company: ${form.company}
📋 Business Type: ${form.businessType}
📌 Services Required: ${form.services.join(", ")}
💰 Turnover: ${form.turnover || "Not specified"}
📱 Mobile: ${form.mobile}
📧 Email: ${form.email}
💬 Message: ${form.message || "Not specified"}
📞 Preferred Contact: ${form.contact}

Please get back to me at your earliest convenience.`;
    window.open(waUrl(text), "_blank");
    setTimeout(() => { setSubmitting(false); setSuccess(true); }, 400);
  }

  const lbl = "block text-sm font-semibold text-[var(--navy)] mb-1.5";
  const inp = "w-full rounded-lg border border-[var(--border)] bg-white px-3.5 py-2.5 text-sm outline-none focus:border-[var(--navy)]";
  const err = "mt-1 text-xs text-red-600";

  return (
    <div className="rounded-[10px] bg-white p-6 md:p-8 card-shadow">
      {success && (
        <div className="mb-6 rounded-lg border border-[var(--green)]/30 bg-[var(--green)]/5 p-4 text-sm text-[var(--green-dark)]">
          ✅ Your enquiry has been prepared! WhatsApp should open automatically. Simply press Send to submit your details to our team. We'll get back to you within 24 hours.
        </div>
      )}
      <div className="grid gap-5 md:grid-cols-2">
        <div>
          <label className={lbl}>Full Name *</label>
          <input className={inp} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          {errors.name && <p className={err}>{errors.name}</p>}
        </div>
        <div>
          <label className={lbl}>Company / Business Name *</label>
          <input className={inp} value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} />
          {errors.company && <p className={err}>{errors.company}</p>}
        </div>
        <div>
          <label className={lbl}>Business Type *</label>
          <select className={inp} value={form.businessType} onChange={(e) => setForm({ ...form, businessType: e.target.value })}>
            <option value="">Select…</option>
            {BUSINESS_TYPES.map(b => <option key={b}>{b}</option>)}
          </select>
          {errors.businessType && <p className={err}>{errors.businessType}</p>}
        </div>
        <div>
          <label className={lbl}>Annual Turnover Range</label>
          <select className={inp} value={form.turnover} onChange={(e) => setForm({ ...form, turnover: e.target.value })}>
            <option value="">Select…</option>
            {TURNOVER.map(t => <option key={t}>{t}</option>)}
          </select>
        </div>
        <div className="md:col-span-2">
          <label className={lbl}>Services Required *</label>
          <div className="flex flex-wrap gap-2">
            {SERVICES.map(s => {
              const on = form.services.includes(s);
              return (
                <button type="button" key={s} onClick={() => toggleService(s)}
                  className={`rounded-full border px-3.5 py-1.5 text-xs font-medium transition ${
                    on ? "border-[var(--green)] bg-[var(--green)] text-white" : "border-[var(--border)] bg-white text-[var(--foreground)] hover:border-[var(--green)]"
                  }`}>{s}</button>
              );
            })}
          </div>
          {errors.services && <p className={err}>{errors.services}</p>}
        </div>
        <div>
          <label className={lbl}>Mobile Number *</label>
          <input className={inp} inputMode="numeric" maxLength={10} value={form.mobile}
                 onChange={(e) => setForm({ ...form, mobile: e.target.value.replace(/\D/g, "") })} />
          {errors.mobile && <p className={err}>{errors.mobile}</p>}
        </div>
        <div>
          <label className={lbl}>Email Address *</label>
          <input className={inp} type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          {errors.email && <p className={err}>{errors.email}</p>}
        </div>
        <div className="md:col-span-2">
          <label className={lbl}>Brief Requirement or Message</label>
          <textarea className={inp} rows={4} placeholder="Tell us a little about what you need help with..."
                    value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
        </div>
        <div className="md:col-span-2">
          <label className={lbl}>Preferred Contact Method *</label>
          <div className="flex flex-wrap gap-4 text-sm">
            {["WhatsApp","Phone Call","Email"].map(c => (
              <label key={c} className="inline-flex items-center gap-2 cursor-pointer">
                <input type="radio" name="contact" checked={form.contact === c}
                       onChange={() => setForm({ ...form, contact: c })} className="accent-[var(--green)]" />
                {c}
              </label>
            ))}
          </div>
        </div>
      </div>
      <button onClick={submit} disabled={submitting}
        className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[var(--green)] py-3 text-sm font-semibold text-white transition hover:bg-[var(--green-dark)] disabled:opacity-70">
        {submitting ? <Loader2 className="animate-spin" size={18} /> : <Send size={18} />}
        Send Enquiry via WhatsApp
      </button>
    </div>
  );
}

export function ContactForm() {
  const [form, setForm] = useState({ name: "", mobile: "", email: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  function submit() {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = "Please enter your name";
    if (!/^\d{10}$/.test(form.mobile)) e.mobile = "Please enter a valid 10-digit mobile number";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = "Please enter a valid email address";
    if (!form.message.trim()) e.message = "Please enter a message";
    setErrors(e);
    if (Object.keys(e).length) return;
    setSubmitting(true);
    const text =
`Hello Fintax Services,

Name: ${form.name}
Mobile: ${form.mobile}
Email: ${form.email}
Message: ${form.message}`;
    window.open(waUrl(text), "_blank");
    setTimeout(() => { setSubmitting(false); setSuccess(true); }, 400);
  }

  const lbl = "block text-sm font-semibold text-[var(--navy)] mb-1.5";
  const inp = "w-full rounded-lg border border-[var(--border)] bg-white px-3.5 py-2.5 text-sm outline-none focus:border-[var(--navy)]";
  const err = "mt-1 text-xs text-red-600";

  return (
    <div className="rounded-[10px] bg-white p-6 md:p-8 card-shadow">
      {success && (
        <div className="mb-6 rounded-lg border border-[var(--green)]/30 bg-[var(--green)]/5 p-3 text-sm text-[var(--green-dark)]">
          Opening WhatsApp... just press Send to reach our team!
        </div>
      )}
      <div className="grid gap-5">
        <div>
          <label className={lbl}>Name *</label>
          <input className={inp} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          {errors.name && <p className={err}>{errors.name}</p>}
        </div>
        <div>
          <label className={lbl}>Mobile *</label>
          <input className={inp} inputMode="numeric" maxLength={10} value={form.mobile}
                 onChange={(e) => setForm({ ...form, mobile: e.target.value.replace(/\D/g, "") })} />
          {errors.mobile && <p className={err}>{errors.mobile}</p>}
        </div>
        <div>
          <label className={lbl}>Email *</label>
          <input className={inp} type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          {errors.email && <p className={err}>{errors.email}</p>}
        </div>
        <div>
          <label className={lbl}>Your Message *</label>
          <textarea className={inp} rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
          {errors.message && <p className={err}>{errors.message}</p>}
        </div>
      </div>
      <button onClick={submit} disabled={submitting}
        className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[var(--green)] py-3 text-sm font-semibold text-white transition hover:bg-[var(--green-dark)] disabled:opacity-70">
        {submitting ? <Loader2 className="animate-spin" size={18} /> : <Send size={18} />}
        Send via WhatsApp
      </button>
    </div>
  );
}
