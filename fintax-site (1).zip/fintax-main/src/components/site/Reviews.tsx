import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, ShieldCheck } from "lucide-react";

type Review = {
  name: string;
  initial: string;
  avatarBg: string;
  timeAgo: string;
  review: string;
};

const REVIEWS: Review[] = [
  { name: "Nayan Patel", initial: "N", avatarBg: "#4B5563", timeAgo: "a week ago", review: "Very Nice Nature, strong hold on subject, solution oriented advise, highly recommended. Thanks to fintax services" },
  { name: "solnkibabubhai189 solanki", initial: "S", avatarBg: "#EA580C", timeAgo: "4 days ago", review: "Our all kind of works like GST and income tax maintain easily here, they inform us all due dates of compliance well in advance, we never face any kind of penalty. Excellent services. For any kind of GST and income tax advice, Highly recommended." },
  { name: "Fahima Global Exports", initial: "F", avatarBg: "#1A2B5F", timeAgo: "2 years ago", review: "Here you will get industry best experience. Both Noman Khan and Majid khan are having sound knowledge of taxation system. Both are also known for kind and professional behaviour. Would highly recommend FinTax for any accounting work." },
  { name: "Mukesh Parmar", initial: "M", avatarBg: "#D97706", timeAgo: "9 months ago", review: "The best and most reliable financial services provider in Kalol." },
  { name: "Spandan Leua", initial: "S", avatarBg: "#2D7A3A", timeAgo: "6 years ago", review: "The best and most reliable financial services provider in town. I had visited it for some financial documents related to my visa process and they helped me perfectly. They provided the accurate documents and were bang on time. Highly recommended." },
  { name: "Yunus Shaikh", initial: "Y", avatarBg: "#16A34A", timeAgo: "6 years ago", review: "Very Good Consultant. I got NCR from authority which was very well handled and accepted. Highly recommended. Thank you Noman Bhai for your services and support." },
  { name: "shirish tripathi", initial: "S", avatarBg: "#4F46E5", timeAgo: "3 years ago", review: "I liked their professionalism which they bring towards the tax work. I would recommend them highly for any tax related work." },
  { name: "nikul patel", initial: "N", avatarBg: "#0D9488", timeAgo: "4 years ago", review: "Fast services. Exact purpose oriented advise." },
  { name: "Hunter kalol kadi", initial: "H", avatarBg: "#D97706", timeAgo: "5 years ago", review: "Best Services in taxation and financial services. They give best and proper advice for any kind of professional query." },
  { name: "S K Sweet", initial: "S", avatarBg: "#DB2777", timeAgo: "6 years ago", review: "They are very honest, hard working, and disciplined in their work. I appreciate Fintax Services. Thank you." },
  { name: "Vedu Shahu", initial: "V", avatarBg: "#7C3AED", timeAgo: "4 years ago", review: "Very very good work. Excellent service." },
  { name: "Shubham Gupta", initial: "S", avatarBg: "#D94F3D", timeAgo: "6 years ago", review: "Perfect place for solutions of finance and wealth support like IT Return Filing, GST Filing, Loans and many more." },
];

function GoogleG({ size = 20 }: { size?: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden="true">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
    </svg>
  );
}

function Stars({ size = 14 }: { size?: number }) {
  return (
    <div style={{ display: "flex", gap: 2 }} aria-label="5 out of 5 stars">
      {Array.from({ length: 5 }).map((_, i) => (
        <span key={i} style={{ color: "#F59E0B", fontSize: size, lineHeight: 1 }}>★</span>
      ))}
    </div>
  );
}

function BigStars({ size = 28 }: { size?: number }) {
  return (
    <div style={{ display: "flex", gap: 4 }} aria-hidden="true">
      {Array.from({ length: 5 }).map((_, i) => (
        <span key={i} style={{ color: "#F59E0B", fontSize: size, lineHeight: 1 }}>★</span>
      ))}
    </div>
  );
}

function ReviewCard({ r }: { r: Review }) {
  return (
    <div
      style={{
        background: "#fff",
        borderRadius: 12,
        boxShadow: "0 2px 12px rgba(0,0,0,0.07)",
        padding: 20,
        minHeight: 180,
        display: "flex",
        flexDirection: "column",
        gap: 12,
        height: "100%",
        boxSizing: "border-box",
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, minWidth: 0, flex: 1 }}>
          <div
            style={{
              width: 44,
              height: 44,
              borderRadius: "50%",
              background: r.avatarBg,
              color: "#fff",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontFamily: "Inter, sans-serif",
              fontWeight: 700,
              fontSize: 18,
              flexShrink: 0,
            }}
          >
            {r.initial}
          </div>
          <div style={{ minWidth: 0 }}>
            <div style={{ fontFamily: "Inter, sans-serif", fontWeight: 600, fontSize: 15, color: "#1A2B5F", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {r.name}
            </div>
            <div style={{ fontFamily: "Inter, sans-serif", fontWeight: 400, fontSize: 12, color: "#9CA3AF" }}>
              {r.timeAgo}
            </div>
          </div>
        </div>
        <GoogleG size={20} />
      </div>
      <Stars size={14} />
      <div
        style={{
          fontFamily: "Inter, sans-serif",
          fontWeight: 400,
          fontSize: 14,
          color: "#374151",
          lineHeight: 1.6,
          display: "-webkit-box",
          WebkitLineClamp: 4,
          WebkitBoxOrient: "vertical",
          overflow: "hidden",
        }}
      >
        {r.review}
      </div>
    </div>
  );
}

function useIsDesktop() {
  const [d, setD] = useState(true);
  useEffect(() => {
    const u = () => setD(window.innerWidth >= 768);
    u();
    window.addEventListener("resize", u);
    return () => window.removeEventListener("resize", u);
  }, []);
  return d;
}

export function Reviews() {
  const isDesktop = useIsDesktop();
  const perView = isDesktop ? 3 : 1;
  const pages = REVIEWS.length - perView + 1;
  const [page, setPage] = useState(0);
  const [paused, setPaused] = useState(false);
  const [direction, setDirection] = useState(1);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    setPage(0);
  }, [perView]);

  useEffect(() => {
    if (paused) return;
    const interval = isDesktop ? 4000 : 5000;
    timer.current = setInterval(() => {
      setDirection(1);
      setPage((p) => (p + 1) % pages);
    }, interval);
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, [paused, pages, isDesktop]);

  const go = (next: number) => {
    setDirection(next > page ? 1 : -1);
    setPage((next + pages) % pages);
  };

  const visible = REVIEWS.slice(page, page + perView);

  return (
    <section
      style={{ background: "#F7F9FC", padding: isDesktop ? "80px 0" : "48px 0" }}
      aria-label="Client Google reviews"
    >
      <div style={{ maxWidth: 1200, margin: "0 auto", paddingLeft: 24, paddingRight: 24 }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", marginBottom: 40 }}>
          <style>{`
            .reviews-h2 { font-family: Montserrat, sans-serif; font-weight: 700; font-size: 32px; color: #2D7A3A; text-align: center; line-height: 1.2; margin: 0 0 8px 0; }
            @media (max-width: 767px){ .reviews-h2 { font-size: 22px; } }
          `}</style>
          <h2 className="reviews-h2">What Our Clients Say</h2>
          <div style={{ width: 64, height: 3, background: "#2D7A3A", borderRadius: 2, marginBottom: 24 }} />
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
            <GoogleG size={20} />
            <span style={{ fontFamily: "Inter, sans-serif", fontWeight: 600, fontSize: 18, color: "#1A2B5F" }}>
              Excellent on Google
            </span>
          </div>
          <div style={{ fontFamily: "Montserrat, sans-serif", fontWeight: 800, fontSize: 48, color: "#1A2B5F", lineHeight: 1 }}>
            5.0
          </div>
          <div style={{ marginTop: 12 }}>
            <BigStars size={28} />
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 12, fontFamily: "Inter, sans-serif", fontWeight: 400, fontSize: 14, color: "#6B7280" }}>
            <ShieldCheck size={14} color="#16A34A" />
            <span>Verified Google Reviews</span>
          </div>
        </div>


        <div
          style={{ position: "relative", width: "100%", overflow: "hidden" }}
          onMouseEnter={() => isDesktop && setPaused(true)}
          onMouseLeave={() => isDesktop && setPaused(false)}
        >
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={page}
              initial={{ opacity: 0, x: direction * 40 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -direction * 40 }}
              transition={{ duration: 0.35, ease: "easeOut" }}
              drag={!isDesktop ? "x" : false}
              dragConstraints={{ left: 0, right: 0 }}
              dragElastic={0.2}
              onDragEnd={(_, info) => {
                if (info.offset.x < -50) go(page + 1);
                else if (info.offset.x > 50) go(page - 1);
              }}
              style={{
                display: "grid",
                gridTemplateColumns: `repeat(${perView}, 1fr)`,
                gap: 20,
              }}
            >
              {visible.map((r, i) => (
                <ReviewCard key={`${page}-${i}`} r={r} />
              ))}
            </motion.div>
          </AnimatePresence>

          {isDesktop && (
            <>
              <button
                onClick={() => go(page - 1)}
                aria-label="Previous reviews"
                style={{
                  position: "absolute",
                  left: -8,
                  top: "50%",
                  transform: "translateY(-50%)",
                  width: 40,
                  height: 40,
                  borderRadius: "50%",
                  background: "#1A2B5F",
                  color: "#fff",
                  border: "none",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                  boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                }}
              >
                <ChevronLeft size={20} />
              </button>
              <button
                onClick={() => go(page + 1)}
                aria-label="Next reviews"
                style={{
                  position: "absolute",
                  right: -8,
                  top: "50%",
                  transform: "translateY(-50%)",
                  width: 40,
                  height: 40,
                  borderRadius: "50%",
                  background: "#1A2B5F",
                  color: "#fff",
                  border: "none",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                  boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                }}
              >
                <ChevronRight size={20} />
              </button>
            </>
          )}
        </div>

        <div style={{ display: "flex", justifyContent: "center", gap: 8, marginTop: 24 }}>
          {Array.from({ length: pages }).map((_, i) => (
            <button
              key={i}
              onClick={() => go(i)}
              aria-label={`Go to slide ${i + 1}`}
              style={{
                width: 10,
                height: 10,
                borderRadius: "50%",
                background: i === page ? "#16A34A" : "transparent",
                border: i === page ? "none" : "1.5px solid #D1D5DB",
                cursor: "pointer",
                padding: 0,
                transition: "all 0.2s",
              }}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
