import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Menu, X, MessageCircle } from "lucide-react";
import logo from "@/assets/fintax-logo.jpeg";
import { waUrl } from "@/lib/site";

const links = [
  { to: "/", label: "Home" },
  { to: "/services", label: "Services" },
  { to: "/about", label: "About Us" },
  { to: "/corporate", label: "For Businesses" },
  { to: "/contact", label: "Contact" },
] as const;

const navbarCss = `
.fx-navbar-root {
  position: fixed !important;
  top: 0 !important;
  left: 0 !important;
  width: 100% !important;
  z-index: 9999 !important;
  background-color: #FFFFFF !important;
  box-shadow: 0 2px 12px rgba(0,0,0,0.08) !important;
}
.fx-navbar {
  height: 72px !important;
  display: flex !important;
  align-items: center !important;
  justify-content: space-between !important;
  padding: 0 16px !important;
}
@media (min-width: 768px) {
  .fx-navbar {
    height: 76px !important;
    padding: 0 36px !important;
  }
}
.fx-logo-wrap {
  display: flex !important;
  align-items: center !important;
  flex-shrink: 0 !important;
  gap: 12px !important;
}
.logo-clip-wrapper {
  width: 54px !important;
  height: 54px !important;
  overflow: hidden !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  flex-shrink: 0 !important;
  position: relative !important;
}
@media (min-width: 768px) {
  .logo-clip-wrapper { width: 64px !important; height: 64px !important; }
}
.logo-img-inner {
  width: 100% !important;
  height: 100% !important;
  object-fit: contain !important;
  transform: scale(1.05) !important;
  transform-origin: center center !important;
  display: block !important;
  flex-shrink: 0 !important;
}
.fx-brand-fintax {
  font-family: Montserrat, sans-serif;
  font-size: 22px !important;
  font-weight: 800 !important;
  color: #1A2B5F !important;
  letter-spacing: 0.06em !important;
  line-height: 1.1 !important;
  display: block !important;
}
@media (min-width: 768px) { .fx-brand-fintax { font-size: 26px !important; } }
.fx-brand-services {
  font-family: Inter, sans-serif;
  font-size: 11px !important;
  font-weight: 600 !important;
  color: #2D7A3A !important;
  letter-spacing: 0.18em !important;
  text-transform: uppercase !important;
  display: block !important;
}
@media (min-width: 768px) { .fx-brand-services { font-size: 13px !important; } }
.fx-hamburger { width: 24px !important; height: 24px !important; color: #1A2B5F !important; }
.fx-mobile-panel {
  background-color: #1A2B5F !important;
  position: fixed !important;
  top: 72px !important;
  left: 0 !important;
  width: 100vw !important;
  min-height: 100vh !important;
  z-index: 9998 !important;
  transition: transform 0.3s ease-out !important;
}
.fx-mobile-panel.closed { transform: translateY(-110%) !important; }
.fx-mobile-panel.open { transform: translateY(0) !important; }
.fx-mobile-link { color: #FFFFFF !important; opacity: 1 !important; }
`;

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [menuVisible, setMenuVisible] = useState(false);
  const [linksVisible, setLinksVisible] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => { setIsMenuOpen(false); }, [pathname]);

  useEffect(() => {
    let t: ReturnType<typeof setTimeout>;
    if (isMenuOpen) {
      setMenuVisible(true);
      t = setTimeout(() => setLinksVisible(true), 10);
    } else {
      setLinksVisible(false);
      t = setTimeout(() => setMenuVisible(false), 300);
    }
    return () => clearTimeout(t);
  }, [isMenuOpen]);

  return (
    <header className="fx-navbar-root" aria-label="Primary navigation">
      <style dangerouslySetInnerHTML={{ __html: navbarCss }} />
      <div className="fx-navbar mx-auto w-full max-w-7xl">
        <Link to="/" className="fx-logo-wrap" aria-label="Fintax Services home">
          <div className="logo-clip-wrapper">
            <img src={logo} alt="Fintax Services Logo" className="logo-img-inner" />
          </div>
          <span className="flex flex-col">
            <span className="fx-brand-fintax">FINTAX</span>
            <span className="fx-brand-services">SERVICES</span>
          </span>
        </Link>

        <nav className="hidden lg:flex items-center gap-8" aria-label="Main">
          {links.map((l) => {
            const active = pathname === l.to;
            return (
              <Link key={l.to} to={l.to}
                className={`relative text-sm font-medium transition-colors ${
                  active ? "text-[var(--navy)]" : "text-[var(--foreground)] hover:text-[var(--navy)]"
                }`}>
                {l.label}
                {active && <span className="absolute -bottom-2 left-0 right-0 h-0.5 bg-[var(--green)]" />}
              </Link>
            );
          })}
        </nav>

        <div className="flex shrink-0 items-center gap-3">
          <a href={waUrl("Hello Fintax Services, I would like a free consultation.")} target="_blank" rel="noopener noreferrer"
            className="hidden md:inline-flex items-center gap-2 rounded-lg bg-[var(--green)] px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-[var(--green-dark)]">
            <MessageCircle size={16} /> Free Consultation
          </a>
          <button onClick={() => setIsMenuOpen((v) => !v)}
            className="lg:hidden inline-flex shrink-0 items-center justify-center rounded-md p-2 text-[var(--navy)]"
            aria-label={isMenuOpen ? "Close menu" : "Open menu"}>
            {isMenuOpen ? <X className="fx-hamburger" /> : <Menu className="fx-hamburger" />}
          </button>
        </div>
      </div>

      {menuVisible && (
        <div className={`fx-mobile-panel lg:hidden ${isMenuOpen ? "open" : "closed"}`} role="dialog" aria-modal="true">
          <nav className="flex flex-col gap-2 px-6 py-8" aria-label="Mobile">
            {links.map((l, i) => (
              <motion.div key={l.to}
                initial={{ opacity: 0, x: -16 }}
                animate={linksVisible ? { opacity: 1, x: 0 } : { opacity: 0, x: -16 }}
                transition={{ delay: i * 0.06, duration: 0.2 }}>
                <Link to={l.to} onClick={() => setIsMenuOpen(false)}
                  className="fx-mobile-link block border-b border-white/10 py-4 text-lg font-medium">
                  {l.label}
                </Link>
              </motion.div>
            ))}
            <motion.a
              initial={{ opacity: 0, x: -16 }}
              animate={linksVisible ? { opacity: 1, x: 0 } : { opacity: 0, x: -16 }}
              transition={{ delay: links.length * 0.06, duration: 0.2 }}
              href={waUrl("Hello Fintax Services, I would like a free consultation.")}
              target="_blank" rel="noopener noreferrer"
              className="fx-mobile-link mt-6 inline-flex items-center justify-center gap-2 rounded-lg bg-[var(--green)] px-4 py-3 text-base font-semibold">
              <MessageCircle size={18} /> Free Consultation
            </motion.a>
          </nav>
        </div>
      )}
    </header>
  );
}
