import { useEffect, useState } from "react";
import { GOOGLE_CONFIG } from "@/config/googlePlaces";

export type LiveReview = {
  authorAttribution?: { displayName?: string; photoUri?: string };
  rating?: number;
  text?: { text?: string };
  relativePublishTimeDescription?: string;
};

export type LiveReviewsData = {
  rating: number;
  totalReviews: number;
  reviews: LiveReview[];
};

export function useLiveReviews() {
  const [data, setData] = useState<LiveReviewsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    const configured =
      GOOGLE_CONFIG.apiKey &&
      GOOGLE_CONFIG.apiKey !== "REPLACE_WITH_API_KEY" &&
      GOOGLE_CONFIG.placeId &&
      GOOGLE_CONFIG.placeId !== "REPLACE_WITH_PLACE_ID";

    if (!configured) {
      setError(true);
      setLoading(false);
      return;
    }

    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(
          `https://places.googleapis.com/v1/places/${GOOGLE_CONFIG.placeId}?fields=rating,userRatingCount,reviews&key=${GOOGLE_CONFIG.apiKey}`
        );
        const json = await res.json();
        if (cancelled) return;
        if (json.rating) {
          setData({
            rating: json.rating,
            totalReviews: json.userRatingCount ?? 0,
            reviews: json.reviews ?? [],
          });
        } else {
          setError(true);
        }
      } catch {
        if (!cancelled) setError(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  return { data, loading, error };
}
