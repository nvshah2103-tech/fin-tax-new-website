// Google Places API configuration for live reviews.
//
// 1. Get Place ID: visit
//    https://developers.google.com/maps/documentation/places/web-service/place-id
//    Search "Fintax Services Kalol Gujarat" and copy the Place ID.
// 2. Get API Key: Google Cloud Console → Enable Places API (New) →
//    Create API Key → Restrict it to your domain.
// When either value is left as the placeholder, the Reviews section will
// silently fall back to the static hardcoded reviews.

export const GOOGLE_CONFIG = {
  placeId: "REPLACE_WITH_PLACE_ID",
  apiKey: "REPLACE_WITH_API_KEY",
};
