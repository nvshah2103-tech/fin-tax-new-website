export const PHONE = "+919033096187";
export const PHONE_DISPLAY = "+91 90330 96187";
export const EMAIL = "fintax3107@gmail.com";
export const ADDRESS = "05, Beside St. Xavier's High School, Nr. Highway, Kalol - 382721, Gandhinagar, Gujarat, India";
export const HOURS = "Monday to Saturday: 10:00 AM – 8:00 PM";
export const TAGLINE = "Right Place, Right Advice";
export const MAPS_EMBED = "https://www.google.com/maps?q=Fintax+Services+Kalol+Gujarat&output=embed";
export const MAPS_LINK = "https://www.google.com/maps/search/Fintax+Services+Kalol+Gujarat";

export function waUrl(text: string) {
  return `https://wa.me/919033096187?text=${encodeURIComponent(text)}`;
}

export const SITE_URL = "https://www.fintaxservices.in";
